var apiSessionToken = "";
var apiBase = "https://bdcdev.in/work/bharatbillpay.com/backups/230801/lms-mw/public/";
const BASEURL = "https://bdcdev.in/work/bharatbillpay.com/latest/customer-insights/api";
const keyFromPw = 'iQCjSieWEfyoeESY';

/*   Verify OTP Form */
const verifyOTPformContainer_ = document.querySelector(".js-verifyOTP");
let form_, formData_, telInputs, clsAddMsg, inputVarifyOtp;
let invalidInputs = [];
if (verifyOTPformContainer_) {
    form_ = verifyOTPformContainer_.querySelector("form");
    formData_ = {
        verifyOtp: {
            el: verifyOTPformContainer_.querySelector("#inpVarifyOtp"),
            value: function () {
                return this.el.value;
            },
        },
    };
    telInputs = verifyOTPformContainer_.querySelectorAll('input[type="tel"]');
    clsAddMsg = document.querySelector(".js-clsAdd");
    inputVarifyOtp = document.querySelector("#inpVarifyOtp");
    verifyOTPformContainer_.querySelectorAll('input[type="hidden"]');
    const allInputs = [...telInputs];
    allInputs.forEach((input) => {
        input.addEventListener("focus", () => {
            input.classList.remove("isEmpty", "isInvalid");
            clsAddMsg.classList.remove("isExpired", "isInvalid");
        });
        input.addEventListener("input", () => {
            input.classList.remove("isEmpty", "isInvalid");
            clsAddMsg.classList.remove("isExpired", "isInvalid");
        });
    });

    form_.addEventListener("input", () => {
        let isFormValid = true;

        /* verifyOtp */
        if (formData_.verifyOtp.value().length === 6) {
            isFormValid = false;
            document.querySelector(".c-form__input").setAttribute("disabled",true)
            // console.log(formData_.verifyOtp.value())
            var mobile_no = sessionStorage.getItem("agent_mobile_no");
            var page = sessionStorage.getItem("page");
            validateOTP(mobile_no, formData_.verifyOtp.value(), page);
        }
    });

    function disabledOTPInput() {
        formData_.verifyOtp.el.classList.add("-disabled");
        formData_.verifyOtp.el.setAttribute("disabled", true);
    }

    function enableOTPInput() {
        formData_.verifyOtp.el.classList.remove("-disabled");
        formData_.verifyOtp.el.removeAttribute("disabled");
    }

    function clrInputValue() {
        inputVarifyOtp.value = "";
    }

    function errorStateRemove() {
        inputVarifyOtp.classList.remove("isEmpty", "isInvalid");
        clsAddMsg.classList.remove("isExpired", "isInvalid");
    }

    // resend otp
    function resetOTP() {
        var resendOtpBtns = document.querySelectorAll("[data-resend-otp]");
        if (resendOtpBtns.length > 0) {
            function counterSet(stepContainer) {
                // var stepContainer = document.querySelector("[data-tab='artist'] [data-step='2']");
                var counterEle = stepContainer.querySelector("[data-counter-seconds]");
                var countTill = counterEle.dataset.counterSeconds;
                var resendContainer = counterEle.closest(".otpResend");

                clearTimeout(resendContainer.countdownTimeout); // Clear the previous countdown timeout

                if (resendContainer.classList.contains("-deactivateCounter")) {
                    resendContainer.classList.remove("-deactivateCounter");
                }

                // Convert countTill to a number
                countTill = parseInt(countTill, 10);

                function formatTime(seconds) {
                    if (seconds < 60) {
                        return seconds;
                    } else {
                        const minutes = Math.floor(seconds / 60);
                        const remainingSeconds = seconds % 60;
                        return `${minutes}:${remainingSeconds < 10 ? "0" : ""}${remainingSeconds}`;
                    }
                }
                // Function to update the counter display
                function updateCounter() {
                    let suffix = countTill <= 60 ? (countTill <= 1 ? "second" : "seconds") : "";
                    let counter = formatTime(countTill);
                    counterEle.textContent = counter + " " + suffix;
                }

                // Initial update of the counter
                updateCounter();

                // Function to decrement the counter and update display
                function decrementCounter() {
                    countTill--;
                    updateCounter();

                    // If countTill is still greater than 0, schedule the next update
                    if (countTill > 0) {
                        resendContainer.countdownTimeout = setTimeout(decrementCounter, 1000); // Call the function after 1 second
                    } else {
                        resendContainer.classList.add("-deactivateCounter");
                    }
                }

                // Start the countdown
                resendContainer.countdownTimeout = setTimeout(decrementCounter, 1000); // Initial call to decrementCounter after 1 second

                errorStateRemove();
                enableOTPInput();
                clrInputValue();
            }
            resendOtpBtns.forEach((btn) => {
                var verifyContainer = btn.closest(".js-formContainer");
                btn.addEventListener("click", () => counterSet(verifyContainer));
                counterSet(verifyContainer);
            });
        }
    }
    resetOTP();
}

var resendOtpBtns_ = document.querySelectorAll("#resend_otp");
if (resendOtpBtns_.length > 0) {
    var resend_otp = document.querySelector("#resend_otp");
    resend_otp.addEventListener("click", () => resendotp());
}

var CryptoJSAesJson = {
    stringify: function (cipherParams) {
        var j = { ct: cipherParams.ciphertext.toString(CryptoJS.enc.Base64) };
        if (cipherParams.iv) j.iv = cipherParams.iv.toString();
        if (cipherParams.salt) j.s = cipherParams.salt.toString();
        return JSON.stringify(j);
    },
    parse: function (jsonStr) {
        var j = JSON.parse(jsonStr);
        var cipherParams = CryptoJS.lib.CipherParams.create({ ciphertext: CryptoJS.enc.Base64.parse(j.ct) });
        if (j.iv) cipherParams.iv = CryptoJS.enc.Hex.parse(j.iv);
        if (j.s) cipherParams.salt = CryptoJS.enc.Hex.parse(j.s);
        return cipherParams;
    },
};

var settings = {
    async: true,
    crossDomain: true,
    url: BASEURL + "/agent.php",
    method: "POST",
    headers: {
        "content-type": "application/x-www-form-urlencoded",
        "cache-control": "no-cache",
    },
    data: {
        apitype: 'agent-token',
    },
};

jq.ajax(settings).done(function (response) {
    response = JSON.parse(response);
    window.token = response.token;
});



function generateAPIToken() {
    var settings = {
        async: true,
        crossDomain: true,
        url: BASEURL + "/agent.php",
        method: "POST",
        headers: {
            authorization: "Bearer " + window.token,
            "cache-control": "no-cache",
            "X-Requested-With": "XMLHttpRequest",
        },
        processData: false,
        contentType: false,
        mimeType: "multipart/form-data",
        data: {
            apitype: 'agent-token',
        },
    };

    jq.ajax(settings).done(function (response) {
        var r = JSON.parse(response);
        if (!r.hasOwnProperty("Error")) {
            token = r.token.original.data.token;
            apiSessionToken = r.apiSessionToken || '';
            sessionStorage.setItem("apiSessionToken", apiSessionToken);
        } else {
            token = r.token.original.data.token;
            return;
        }
    });
}

function generateOTP(param1, param2) {
    var form = new FormData();

    //sessionStorage.setItem("mobile_no", btoa(param1));
    var mobile_no = userJSEncrypt(param1, keyFromPw);
    //var password = userJSEncrypt(param2, keyFromPw);

    form.append("mobile_no", btoa(mobile_no));
    //form.append("password", btoa(password));
    form.append("apitype", 'agent-otp-verify')

    var settings = {
        async: true,
        crossDomain: true,
        url: BASEURL + "/agent.php",
        method: "POST",
        headers: {
            authorization: "Bearer " + window.token,
            "cache-control": "no-cache",
            "X-Requested-With": "XMLHttpRequest",
        },
        processData: false,
        contentType: false,
        mimeType: "multipart/form-data",
        data: form,
    };

    jq.ajax(settings).done(function (response) {
        var r = JSON.parse(response);
        if (r.message == "success") {
            window.token = r.token.original.data.token;
            window.location.href = "agent-locator/verify-otp";
        } else {
            window.token = r.token.original.data.token;
            let serverValidationId = "password";
            let errorMessage = r.message;
            let scrollToEl = document.querySelector(`[data-server-validation-id="${serverValidationId}"]`);
            setErrorMessage(serverValidationId, errorMessage);
            scrollToEl.scrollIntoView({ block: "center" });
            return;
        }
    });
}

function resendotp() {
    var form = new FormData();
    form.append('apitype', 'agent-resend-otp');
    // var apiSessionToken = sessionStorage.getItem("apiSessionToken");
    // var mobile_no = sessionStorage.getItem("agent_mobile_no");

    // form.append("mobile_no", mobile_no);
    // form.append("apitoken", apiSessionToken);

    var settings = {
        async: true,
        crossDomain: true,
        url: BASEURL + "/agent.php",
        method: "POST",
        headers: {
            authorization: "Bearer " + window.token,
            "cache-control": "no-cache",
            "X-Requested-With": "XMLHttpRequest",
        },
        processData: false,
        contentType: false,
        mimeType: "multipart/form-data",
        data: form,
    };

    jq.ajax(settings).done(function (response) {
        var r = JSON.parse(response);
        if (r.message == "success") {
            window.token = r.data.token;
        } else {
            window.token = r.data.token;
            formData_.verifyOtp.el.classList.remove("isInvalid");
            clsAddMsg.classList.remove("isInvalid");
            let serverValidationId = "otp";
            let errorMessage = r?.error ?? '';
            let scrollToEl = document.querySelector(`[data-server-validation-id="${serverValidationId}"]`);
            if (Object.keys((r?.formErrors) ?? {}).length > 0) {
                errorMessage = "";
                let messages = Object.values(r.formErrors);
                messages.forEach((values) => {
                    values.forEach((value, index) => {
                        errorMessage += value;
                        if (index <= values.length - 2) {
                            errorMessage += "<br/>";
                        }
                    });
                });
            }
            setErrorMessage(serverValidationId, errorMessage);
            scrollToEl.scrollIntoView({ block: "center" });
            return;
        }
    });
}

function registerotp(param1) {
    var form = new FormData();
    var mobile_no = userJSEncrypt(param1, keyFromPw);
    form.append("mobile_no", btoa(mobile_no));
    form.append("apitype", 'agent-otp');

    var settings = {
        async: true,
        crossDomain: true,
        url: BASEURL + "/agent.php",
        method: "POST",
        headers: {
            authorization: "Bearer " + window.token,
            "cache-control": "no-cache",
            "X-Requested-With": "XMLHttpRequest",
        },
        processData: false,
        contentType: false,
        mimeType: "multipart/form-data",
        data: form,
    };

    jq.ajax(settings).done(function (response) {
        var r = JSON.parse(response);
        if (r.status) {
            window.token = r.data.token;
            window.location.href = "agent-locator/verify-otp";
        } else {
            window.token = r.data.token;

            let serverValidationId = "mobile_no";
            let errorMessage = (r?.formErrors?.[0]?.mobile_no) ?? '';
            let scrollToEl = document.querySelector(`[data-server-validation-id="${serverValidationId}"]`);
            /* Object.keys(r.message).forEach((key) => {
                errorMessage = r.message[key];
            }); */
            setErrorMessage(serverValidationId, errorMessage);
            scrollToEl.scrollIntoView({ block: "center" });
            return;
        }
    });
}
function setErrorMessage(serverValidationId, errorMessage) {
    console.log(serverValidationId + " : " + errorMessage);
    const inputWrapperEl = document.querySelector(`[data-server-validation-id="${serverValidationId}"]`);
    inputWrapperEl.classList.add("hasServerError");
    const errorMessageEl = inputWrapperEl.querySelector(".js-formInputServerError");
    errorMessageEl.innerHTML = errorMessage;
}
function validateOTP(param1, param2, param3 = null) {
    var form = new FormData();
    var page = sessionStorage.getItem('page') || 'na';
    //var mobile_no = userJSEncrypt(param1, keyFromPw);
    var otp = userJSEncrypt(param2, keyFromPw);
    //form.append("mobile_no", param1);
    form.append("otp", btoa(otp));
    form.append("apitype", 'agent-verify-otp');

    var settings = {
        async: true,
        crossDomain: true,
        url: BASEURL + "/agent.php",
        method: "POST",
        headers: {
            authorization: "Bearer " + window.token,
            "cache-control": "no-cache",
            "X-Requested-With": "XMLHttpRequest",
        },
        processData: false,
        contentType: false,
        mimeType: "multipart/form-data",
        data: form,
    };

    jq.ajax(settings).done(function (response) {
        var r = JSON.parse(response);
        if (r.status) {
            window.token = r.data.token;
            // sessionStorage.setItem("sessionToken", btoa(r.sessionToken));
            disabledOTPInput();
            document.querySelector(".dot-flashing").style.display = "block";
            document.querySelector(".js-otpVerified").classList.add("is-verified");
            setTimeout(() => {
                if (param3 == "agent-located-login") {
                    window.location.href = "agent-locator/agent-locator-search";
                } else {
                    LoginSuccess(param1);
                }
            }, 3000);
        } else {
            window.token = r.data.token;
            isFormValid = false;
            var errorObj = (r?.formErrors) ?? {};
            var errorMessages = Object.values(errorObj);
            if (errorMessages.includes('OTP has been expired.')) {
                formData_.verifyOtp.el.classList.add("isExpired");
                clsAddMsg.classList.add("isExpired");
            } else {
                formData_.verifyOtp.el.classList.add("isInvalid");
                clsAddMsg.classList.add("isInvalid");
            }
            invalidInputs.push(formData_.verifyOtp.el);
            enableOTPInput();
        }
    });
}

function LoginSuccess(param1) {
    window.location.href = "agent-locator/agent-locator-search";
    return;
    /*
    var form = new FormData();
    form.append('apitype', 'transaction-history')
    // var mobile_no = userJSEncrypt(param1, keyFromPw);
    // var apiSessionToken = sessionStorage.getItem("apiSessionToken");
    // var sessionToken = sessionStorage.getItem("sessionToken");
    // var mobile_no = sessionStorage.getItem("agent_mobile_no");

    // form.append("mobile_no", mobile_no);
    // form.append("sessionToken", sessionToken);
    // form.append("apiSessionToken", apiSessionToken);

    var settings = {
        async: true,
        crossDomain: true,
        url: BASEURL + "/agent.php",
        method: "POST",
        headers: {
            authorization: "Bearer " + window.token,
            "cache-control": "no-cache",
            "X-Requested-With": "XMLHttpRequest",
        },
        processData: false,
        contentType: false,
        mimeType: "multipart/form-data",
        data: form,
    };

    jq.ajax(settings).done(function (response) {
        var r = JSON.parse(response);
        if (r.message == "success") {
            window.location.href = "transaction-overview";
        } else {
            window.location.href = "customer-insights/log-in";
        }
    });
    */
}

function registeruser(param1, param2, param3) {
    var form = new FormData();
    var password = userJSEncrypt(param1, keyFromPw);
    var cpassword = userJSEncrypt(param2, keyFromPw);
    form.append("password", btoa(password));
    form.append('apitype', 'register-user');
    form.append("password_confirmation", btoa(cpassword));

    var settings = {
        async: true,
        crossDomain: true,
        url: BASEURL + "/agent.php",
        method: "POST",
        headers: {
            authorization: "Bearer " + window.token,
            "cache-control": "no-cache",
            "X-Requested-With": "XMLHttpRequest",
        },
        processData: false,
        contentType: false,
        mimeType: "multipart/form-data",
        data: form,
    };

    jq.ajax(settings).done(function (response) {
        var r = JSON.parse(response);
        if (r.message == "Insert successful.") {
            window.token = r.token.original.data.token;
            window.location.href = "customer-insights/log-in";
        } else {
            window.token = r.token.original.data.token;
            let serverValidationId = "password_confirmation";
            let errorMessage = r.message;
            let scrollToEl = document.querySelector(`[data-server-validation-id="${serverValidationId}"]`);
            Object.keys(r.message).forEach((key) => {
                errorMessage = r.message[key];
            });
            setErrorMessage(serverValidationId, errorMessage);
            scrollToEl.scrollIntoView({ block: "center" });
            return;
        }
    });
}



