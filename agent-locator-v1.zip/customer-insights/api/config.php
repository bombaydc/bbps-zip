<?php
session_start();
define('API_URL', 'https://bdcdev.in/work/bharatbillpay.com/backups/230801/lms-mw/public/');
define('BASE_URL', 'https://bdcdev.in/work/bharatbillpay.com/latest/');
define('ENCRYPTION_KEY', 'iQCjSieWEfyoeESY');
define('SRCID', 'BBPS_RL01');
define('SECRETKEY', 'GH771981');


$servername = "localhost";
$username = "bdcdb_usr";
$password = "C1r1t@123";
$dbname = "bbps_lms";

$srcId = "BBPS_RL01";
$secretKey = "GH771981";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}


function curlPostRequest($path = '', $token = '', $formData = [])
{
  $curl = curl_init();
  if ($_SESSION['session_token'] ?? '') {
    $formData['apitoken'] = $_SESSION['session_token'];
  }
  curl_setopt_array($curl, array(
    CURLOPT_URL => API_URL . $path,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'POST',
    CURLOPT_POSTFIELDS => $formData,
    CURLOPT_HTTPHEADER => array(
      'X-Requested-With: XMLHttpRequest',
      'cache-control: no-cache',
      'Authorization: Bearer ' . $token,
    ),
  ));
  $response = curl_exec($curl);
  $httpcode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
  curl_close($curl);
  $resp['http_resp'] = json_decode($response, true);
  $resp['http_code'] = $httpcode;
  return $resp;
}


function cryptoJsAesEncrypt($passphrase, $plainText)
{
  $SALT = "aRb0txx2kqkwdmuU"; //salt
  $IV = "iDMKTpfrFrHi2czx"; //pass salt minimum length 12 chars or it'll be show warning messages
  $ITERATIONS = 999; //iterations
  $key = \hash_pbkdf2("sha256", $passphrase, $SALT, $ITERATIONS, 64);
  $encryptedData = \openssl_encrypt(
    $plainText,
    "AES-256-CBC",
    \hex2bin($key),
    OPENSSL_RAW_DATA,
    $IV
  );
  return \base64_encode($encryptedData);
}

function cryptoJsAesDecrypt($passphrase, $encryptedTextBase64)
{
  $SALT = "aRb0txx2kqkwdmuU"; //salt
  $IV = "iDMKTpfrFrHi2czx"; //pass salt minimum length 12 chars or it'll be show warning messages
  $ITERATIONS = 999; //iterations
  $encryptedText = \base64_decode($encryptedTextBase64);
  $key = \hash_pbkdf2("sha256", $passphrase, $SALT, $ITERATIONS, 64);
  $decryptedText = \openssl_decrypt(
    $encryptedText,
    "AES-256-CBC",
    \hex2bin($key),
    OPENSSL_RAW_DATA,
    $IV
  );
  return $decryptedText;
}


/** 
 * Get header Authorization
 * */
function getAuthorizationHeader()
{
  $headers = null;
  if (isset($_SERVER['Authorization'])) {
    $headers = trim($_SERVER["Authorization"]);
  } else if (isset($_SERVER['HTTP_AUTHORIZATION'])) { //Nginx or fast CGI
    $headers = trim($_SERVER["HTTP_AUTHORIZATION"]);
  } elseif (function_exists('apache_request_headers')) {
    $requestHeaders = apache_request_headers();
    // Server-side fix for bug in old Android versions (a nice side-effect of this fix means we don't care about capitalization for Authorization)
    $requestHeaders = array_combine(array_map('ucwords', array_keys($requestHeaders)), array_values($requestHeaders));
    //print_r($requestHeaders);
    if (isset($requestHeaders['Authorization'])) {
      $headers = trim($requestHeaders['Authorization']);
    }
  }
  return $headers;
}

/**
 * get access token from header
 * */
function getBearerToken()
{
  $headers = getAuthorizationHeader();
  // HEADER: Get the access token from the header
  if (!empty($headers)) {
    if (preg_match('/Bearer\s(\S+)/', $headers, $matches)) {
      return $matches[1];
    }
  }
  return '';
}

function getJsonData($pathJson = "")
{
  $pageData = [];
  try {
    if (file_exists($pathJson)) {
      $pageDataString = trim(file_get_contents($pathJson) ?? '{}', "\xEF\xBB\xBF");
      $pageData = json_decode($pageDataString ?? '{}', true, 512, JSON_BIGINT_AS_STRING);
    }
  } catch (\Throwable $th) {
    $pageData = [];
  }
  return $pageData;
}

function base_url($path = '')
{
  // Remove leading and trailing slashes
  $path = trim($path, '/');
  if (!$path)
    return BASE_URL;

  // Separate path and query parameters
  $parts = explode('?', $path, 2);
  $path = $parts[0];
  $path = trim($path, '/');
  $query = isset($parts[1]) ? '?' . $parts[1] : '';

  // Check if the path ends with a media file extension
  $mediaFileExtensions = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg', 'webp', 'mp4', 'avi', 'mov', 'wmv', 'flv', 'pdf'];
  $isMediaFile = false;
  foreach ($mediaFileExtensions as $extension) {
    if (preg_match("/\.{$extension}$/i", $path)) {
      $isMediaFile = true;
      break;
    }
  }
  if (!$isMediaFile) {
    $path .= '/';
  }

  // Add BASE_URL and ensure a single trailing slash
  $fullUrl = rtrim(BASE_URL, '/') . '/' . $path . $query;

  return $fullUrl;
}
