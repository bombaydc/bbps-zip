<?php
include_once('config.php');
define('COOLDOWNDURATION', 300);
define('RATELIMT', 50);
define('RLDURATIONSECOND', 60);


function generateCSRFToken()
{
    $token = bin2hex(random_bytes(32)); // Generate a random token
    $_SESSION['csrf_token'] = $token; // Store the token in the session
    return $token;
}

function verifyCSRFToken($token)
{
    // Retrieve the token stored in the session
    $sessionToken = $_SESSION['csrf_token'] ?? null;
    // Compare the tokens
    return hash_equals($sessionToken, $token);
}

function generateOTP()
{
    // Generate a random 6-digit number
    return "123456";
    return str_pad(mt_rand(0, 999999), 6, '0', STR_PAD_LEFT);
}

function isValidIndianMobileNumber($number)
{
    // Remove any non-numeric characters from the number
    $number = preg_replace('/[^0-9]/', '', $number);

    // Check if the number starts with 6, 7, 8, or 9 and is exactly 10 digits long
    return preg_match('/^[6-9][0-9]{9}$/', $number);
}

function sendAgentSMS($mobile, $message)
{
    return true;
}

$action = $_POST['apitype'] ?? '';

function agentOtpSend($encryptMobile)
{
    try {
        $mobile = cryptoJsAesDecrypt(ENCRYPTION_KEY, base64_decode($encryptMobile ?? ''));

        if (!verifyCSRFToken(getBearerToken()))
            return ['status' => false, 'data' => ['token' => generateCSRFToken()], 'formErrors' => [], 'error' => 'Request action not allowed.'];
        if (!isValidIndianMobileNumber($mobile)) {
            return ['status' => false, 'data' => ['token' => generateCSRFToken()], 'formErrors' => ['mobile_no' => 'Mobile number not valid.'], 'error' => 'Validation error occured.'];
        }
        $otp = generateOTP();
        // sendotp function go here
        $_SESSION['agent_mobile'] = $mobile;
        $_SESSION['otp'] = $otp;
        $_SESSION['expireTime'] = time() + 300;
        return ['status' => true, 'data' => ['token' => generateCSRFToken()], 'message' => 'OTP has been send on mobile number'];
    } catch (\Throwable $th) {
        //throw $th;
        return ['status' => false, 'data' => ['token' => generateCSRFToken()], 'formErrors' => ['mobile_no' => 'Mobile number not valid.'], 'error' => 'Validation error occured.'];
    }
    //validation goes here also set mobile number in session

}

function agentOtpResend()
{
    try {
        if (!verifyCSRFToken(getBearerToken()))
            return ['status' => false, 'data' => ['token' => generateCSRFToken()], 'formErrors' => [], 'error' => 'Request action not allowed.'];

        $mobile = $_SESSION['agent_mobile'];

        $otp = generateOTP();
        $_SESSION['agent_mobile'] = $mobile;
        $_SESSION['otp'] = $otp;
        $_SESSION['expireTime'] = time() + 300;
        return ['status' => true, 'data' => ['token' => generateCSRFToken()], 'message' => 'OTP has been send on mobile number'];
    } catch (\Throwable $th) {
        //throw $th;
        return ['status' => false, 'data' => ['token' => generateCSRFToken()], 'formErrors' => [], 'error' => 'Validation error occured.'];
    }
}

function verifyOtp($encrptedOtp)
{
    try {
        $otp = cryptoJsAesDecrypt(ENCRYPTION_KEY, base64_decode($encrptedOtp ?? ''));

        if (!verifyCSRFToken(getBearerToken()))
            return ['status' => false, 'data' => ['token' => generateCSRFToken()], 'formErrors' => [], 'error' => 'Request action not allowed.'];

        $expireTime = $_SESSION['expireTime'] ?? '0';
        if ($expireTime < time())
            return ['status' => false, 'data' => ['token' => generateCSRFToken()], 'formErrors' => ['otp' => 'OTP has been expired.'], 'error' => 'Validation error occured.'];

        if ($otp != ($_SESSION['otp'] ?? ''))
            return ['status' => false, 'data' => ['token' => generateCSRFToken()], 'formErrors' => ['otp' => 'OTP is not valid.'], 'error' => 'Validation error occured.'];
        unset($_SESSION['otp']);
        unset($_SESSION['expireTime']);
        //unset($_SESSION['agent_mobile']);
        $_SESSION['isAgentVerify'] = true;
        return ['status' => true, 'data' => ['token' => generateCSRFToken()]];
    } catch (\Throwable $th) {
        //throw $th;
        return ['status' => false, 'data' => ['token' => generateCSRFToken()], 'formErrors' => ['otp' => 'OTP is not valid.'], 'error' => 'Validation error occured.'];
    }
}

function getSearchData($search, $searchType = "cordinates")
{
    return ["status" => false, 'data' => [], 'message' => 'No data found', 'error' => 'Request time out.'];
    return json_decode(file_get_contents('../../agent-locator/agent-locator-search/agent-locator.json'), true);
}


function spiceMoneyAuth($count = 1)
{
    if (($_SESSION['spice'] ?? '')) {
        return true;
    }
    if ($count == 10) {
        return false;
    }

    $ipAddress = $_SERVER['REMOTE_ADDR'];
    $uniqueId = uniqid();


    $payload = [
        "client_id" => "BBPS123",
        "client_secret" => "GupShup2202Spic3m0n3ysp1c3s3archAg12090",
        "customer" => [
            "deviceid" => $ipAddress,
            "uniqueid" => $uniqueId
        ]
    ];
    $curl = curl_init();

    curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://stgpayments.spicemoney.com/spice-search/stag/auth/v1/get-token',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => json_encode($payload),
        CURLOPT_HTTPHEADER => array(
            'Content-Type: application/json',
        ),
    ));

    $response = curl_exec($curl);
    curl_close($curl);
    $resp = json_decode($response ?? '{}', true);
    // echo json_encode($payload);
    // echo 'hi';
    // echo $response;
    /*
        427 => Dear User, the limit for searches per session is exhausted. Please create a new session to proceed further.
        429 => Invalid Request Type. Please pass the correct request type (PINCODE/GEO_CODE) to proceed further.
        422 => Oops! Something went wrong.
        424 => Invalid Token. Please pass the correct token to proceed further.
        431 => Invalid Client Secret ID. Please pass the correct secret ID to proceed further.
        426 => Dear User, SMA details for a particular location can be searched only if the location is within a range of 100 Km from your current location.
        430 => Oops! Something went wrong.
        425 => Invalid pin code. Please enter the correct pin code to proceed further.
        421 => Dear User, the daily limit for the following unique ID is exhausted. Please try again tomorrow.
    */
    if (($resp['code'] ?? 'na') == '0') {
        $_SESSION['spice']['uniqueId'] = $uniqueId;
        $_SESSION['spice']['ip_address'] = $ipAddress;
        $_SESSION['spice']['token'] = $resp['access_token'];
        return true;
    } else {
        // kill request after 10 call
        if (in_array(($resp['code'] ?? ''), ['427', '421', '424', '431'])) {
            unset($_SESSION['spice']);
            return spiceMoneyAuth($count++);
        }
    }
    return false;
}

function spiceMoneyAgents($formData, $count = 1)
{
    if ($count >= 10) {
        return ["status" => false, 'data' => [], 'message' => 'No data found', 'error' => 'Request time out.'];
    }
    if (!spiceMoneyAuth()) {
        return ['status' => false, 'data' => [], 'message' => 'No data found', 'error' => 'api auth fail.'];
    }

    if ($formData['currentLocation'] ?? '') {
        $currentCordinates = json_decode($formData['currentLocation'], true);
        $currentLat = $currentCordinates['lat'] ?? '';
        $currentLon = $currentCordinates['lon'] ?? '';
    }

    if (($formData['searchType'] ?? '') == 'pincode') {
        $requestType = "PINCODE";
        $pincode = $formData['search'];
    } else {
        $requestType = "GEO_CODE";
        $cordinates = json_decode($formData['search'], true);
        $lat = $cordinates['lat'] ?? '';
        $lon = $cordinates['lon'] ?? '';
    }
    $payload = [
        "requestType" => $requestType, //"PINCODE",
        "orgId" => "2XAC0HMFBC4GR8XSCUV",
        "timestamp" => "2024-05-08T13:21:15+05:30",
        "data" => [
            "coordinates" => [
                "latitude" => $lat ?? '', // optional
                "longitude" => $lon ?? '', // optional
                "currentLat" => $currentLat ?? '',
                "currentLong" => $currentLon ?? ''

            ],
            "address" => [
                "countryCode" => "IN",
                "pinCode" => $pincode ?? ''
            ],
            "customer" => [
                "uniqueid" => ($_SESSION['spice']['uniqueId'] ?? ''),
                "deviceid" => ($_SESSION['spice']['ip_address'] ?? '')
            ]
        ]
    ];
    $curl = curl_init();

    curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://stgpayments.spicemoney.com/spice-search/stag/agentlocator/BBPS123',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => json_encode($payload),
        CURLOPT_HTTPHEADER => array(
            'Authorization: ' . ($_SESSION['spice']['token'] ?? ''),
            'Content-Type: application/json'
        ),
    ));

    $response = curl_exec($curl);
    curl_close($curl);
    $resp = json_decode($response ?? '{}', true);
    if (($resp['code'] ?? '') == '200') {
        return ["status" => true, 'data' => $resp['data'] ?? [], 'message' => 'Data found', 'error' => ''];
    } else {
        // kill request after 10 call
        if (in_array($resp['code'] ?? '', ['427', '421', '424', '431'])) {
            if ($_SESSION['spice'] ?? '') {
                unset($_SESSION['spice']);
            }
            return spiceMoneyAgents($formData, $count++);
        }
    }
    return ["status" => false, 'data' => [], 'message' => 'No data found', 'error' => 'api data not found.'];
}

function isRequestLimitExceeded()
{
    if (isset($_SESSION['cooldown_start_time']) && ($_SESSION['cooldown_start_time'] - time()) > 0) {
        return true;
    }
    // Check if the request count session variable exists
    if (!isset($_SESSION['request_count'])) {
        $_SESSION['request_count'] = 1;
        $_SESSION['request_start_time'] = time();
        if (isset($_SESSION['cooldown_start_time']))
            unset($_SESSION['cooldown_start_time']);
    } else {
        // Increment the request count if it's within the time window
        $currentTime = time();
        $startTime = $_SESSION['request_start_time'];
        $elapsedTime = $currentTime - $startTime;

        // If 1 minute has elapsed, reset the request count
        if ($elapsedTime >= RLDURATIONSECOND) {
            $_SESSION['request_count'] = 1;
            $_SESSION['request_start_time'] = $currentTime;
            unset($_SESSION['cooldown_start_time']);
            return false;
        } else {
            // Check if the request count exceeds the limit
            if ($_SESSION['request_count'] >= RATELIMT) {
                // If the request limit is exceeded, check if the cooldown period is over
                $cooldownStartTime = $_SESSION['cooldown_start_time'] ?? null;
                if ($cooldownStartTime === null) {
                    $_SESSION['cooldown_start_time'] = time() + COOLDOWNDURATION;
                    // Reset request count and cooldown start time
                    unset($_SESSION['request_count'], $_SESSION['request_start_time']);
                    return true;
                } else if (($cooldownStartTime - $currentTime) <= 0) {
                    $_SESSION['request_count'] = 1;
                    $_SESSION['request_start_time'] = $currentTime;
                    unset($_SESSION['cooldown_start_time']);
                    return false;
                } else {
                    // Cooldown period still active
                    $_SESSION['cooldown_start_time'] = time() + COOLDOWNDURATION;
                    unset($_SESSION['request_count'], $_SESSION['request_start_time']);
                    return true;
                }
            } else {
                $_SESSION['request_count']++;
                return false;
            }
        }
    }

    return false; // Request limit not exceeded
}
function isRequestLimitExceededTest()
{
    if (isset($_SESSION['cooldown_start_time']) && ($_SESSION['cooldown_start_time'] - time()) > 0) {
        echo "Blocked due to cooldown";
        return true;
    }
    // Check if the request count session variable exists
    if (!isset($_SESSION['request_count'])) {
        $_SESSION['request_count'] = 1;
        //echo 'if-1-' . $_SESSION['request_count'];
        $_SESSION['request_start_time'] = time();
        echo "Request - " . $_SESSION['request_count'];
        unset($_SESSION['cooldown_start_time']);
        return false;
    } else {
        echo "Request - " . $_SESSION['request_count'];
        echo '<br>';
        // Increment the request count if it's within the time window
        $currentTime = time();
        $startTime = $_SESSION['request_start_time'];
        $elapsedTime = $currentTime - $startTime;

        // If 1 minute has elapsed, reset the request count
        if ($elapsedTime >= RLDURATIONSECOND) {
            $_SESSION['request_count'] = 1;
            //echo 'else-if-' . $_SESSION['request_count'];
            $_SESSION['request_start_time'] = $currentTime;
            unset($_SESSION['cooldown_start_time']);
            echo "elapsed 1 min request start";
            return false;
        } else {
            // Check if the request count exceeds the limit
            if ($_SESSION['request_count'] >= RATELIMT) {
                echo "Rate limit Exhaust";
                echo '<br>';
                // If the request limit is exceeded, check if the cooldown period is over
                $cooldownStartTime = $_SESSION['cooldown_start_time'] ?? null;
                if ($cooldownStartTime === null) {
                    $_SESSION['cooldown_start_time'] = time() + COOLDOWNDURATION;
                    // Reset request count and cooldown start time
                    echo 'Cool down period null';
                    //unset($_SESSION['request_count'], $_SESSION['request_start_time']);
                    return true;
                } else if (($cooldownStartTime - $currentTime) <= 0) {
                    $_SESSION['request_count'] = 1;
                    echo 'check Cool down period - result - ' . (($cooldownStartTime - $currentTime) <= 0) . ' - cool down time - ' . $cooldownStartTime . ' current time' . $currentTime;
                    $_SESSION['request_start_time'] = $currentTime;
                    unset($_SESSION['cooldown_start_time']);
                    return false;
                } else {
                    // Cooldown period still active
                    echo 'rate limit exhuated else condition';
                    $_SESSION['cooldown_start_time'] = time() + COOLDOWNDURATION;
                    //unset($_SESSION['request_count'], $_SESSION['request_start_time']);
                    return true;
                }
            } else {
                $_SESSION['request_count']++;
                echo 'Request Count increases';
                return false;
            }
        }
    }

    //return false; // Request limit not exceeded
}

if (strpos($action, 'agent-search-') !== false) {
    // isRequestLimitExceededTest();
    // exit;
    if (isRequestLimitExceeded()) {
        $resp = ["status" => false, 'data' => [], 'message' => 'Rate Limit exhuated.', 'error' => '429', 'timeResume' => $_SESSION['cooldown_start_time'] * 1000];;
        echo json_encode($resp);
        exit;
    }
    //exit;
}





switch ($action) {
    case "agent-token":
        $resp = json_encode(['status' => true, 'token' => generateCSRFToken()]);
        break;
    case "agent-otp":
        // verify otp here
        $resp = json_encode(agentOtpSend($_POST['mobile_no'] ?? ''));
        break;
    case "agent-resend-otp":
        $resp = json_encode(agentOtpResend());
        break;
    case "agent-verify-otp":
        $resp = json_encode(verifyOtp($_POST['otp'] ?? ''));
        break;
    case "agent-search-1":
        $resp = json_encode(spiceMoneyAgents($_POST ?? '{}'));
        break;
    case "agent-search-2":
        $resp = json_encode(getSearchData($_POST['search'] ?? '{}', $_POST['searchType'] ?? 'cordinates'));
        break;
    case "agent-search-3":
        $resp = json_encode(getSearchData($_POST['search'] ?? '{}', $_POST['searchType'] ?? 'cordinates'));
        break;
    case "agent-search-4":
        $resp = json_encode(getSearchData($_POST['search'] ?? '{}', $_POST['searchType'] ?? 'cordinates'));
        break;
    case "agent-search-5":
        $resp = json_encode(getSearchData($_POST['search'] ?? '{}', $_POST['searchType'] ?? 'cordinates'));
        break;
    default:
        $resp = '{"status":false, "message":"Action not allowed."}';
        break;
}

echo $resp;
exit;
