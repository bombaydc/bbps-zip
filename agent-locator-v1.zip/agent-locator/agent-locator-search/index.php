<?php
include_once('../../customer-insights/api/config.php');

if (!($_SESSION['isAgentVerify'] ?? '')) {
	header('Location: ' . BASE_URL . '/agent-locator/verify-your-account');
	exit;
}

if (($_SESSION['cooldown_start_time'] ?? '') && $_SESSION['cooldown_start_time'] - time() > 0) {
	$coolDownResume = $_SESSION['cooldown_start_time'];
}
?>
<!DOCTYPE html>
<html lang="en" data-page="agent-locator-search">

<head>
	<base href="../../" />
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<title>Agent locator | Bharat BillPay</title>
	<meta name="description" content="Create a strong and secure password to protect your account. Set your password now and ensure the safety of your online information." />
	<meta name="google-site-verification" content="biehzyFvzLsFbRq7xI-UoIFRGjBcZmjJgD1iAxUflow" />
	<meta property="og:type" content="website" />
	<meta property="og:url" content="https://www.bharatbillpay.com/" />
	<meta property="og:title" content="Agent locator | Bharat BillPay" />
	<meta property="og:description" content="Create a strong and secure password to protect your account. Set your password now and ensure the safety of your online information." />
	<meta property="og:image" content="https://bdcdev.in/work/bharatbillpay.com/latest/assets/images/pages/social-share-bbps.jpg" />
	<meta name="twitter:card" content="summary_large_image" />
	<meta name="twitter:site" content="@BharatBillPay" />
	<meta name="twitter:creator" content="@BharatBillPay" />
	<meta name="twitter:title" content="Agent locator | Bharat BillPay" />
	<meta name="twitter:description" content="Create a strong and secure password to protect your account. Set your password now and ensure the safety of your online information." />
	<meta name="twitter:image" content="https://bdcdev.in/work/bharatbillpay.com/latest/assets/images/pages/social-share-bbps.jpg" />
	<link rel="shortcut icon" href="assets/favicon/favicon.png" type="image/x-icon" />
	<link rel="stylesheet" type="text/css" href="css/main.min.css" />
	<link rel="stylesheet" type="text/css" href="css/pages/agent-locator/agent-locator-search.min.css" />
	<link rel="preconnect" href="https://fonts.googleapis.com" />
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500&display=swap" rel="stylesheet" />
	<!-- Google tag (gtag.js) -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=UA-113582445-1"></script>
	<script>
		window.dataLayer = window.dataLayer || [];

		function gtag() {
			dataLayer.push(arguments);
		}
		gtag("js", new Date());

		gtag("config", "UA-113582445-1");
	</script>
	<!-- Google tag (gtag.js) -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=G-NSHLRBR254"></script>
	<script>
		window.dataLayer = window.dataLayer || [];

		function gtag() {
			dataLayer.push(arguments);
		}
		gtag("js", new Date());

		gtag("config", "G-NSHLRBR254");
	</script>
	<!-- Clarity -->
	<script type="text/javascript">
		(function(c, l, a, r, i, t, y) {
			c[a] =
				c[a] ||
				function() {
					(c[a].q = c[a].q || []).push(arguments);
				};
			t = l.createElement(r);
			t.async = 1;
			t.src = "https://www.clarity.ms/tag/" + i;
			y = l.getElementsByTagName(r)[0];
			y.parentNode.insertBefore(t, y);
		})(window, document, "clarity", "script", "hquvwne1n0");
	</script>
	<!-- Google Tag Manager -->
	<script>
		(function(w, d, s, l, i) {
			w[l] = w[l] || [];
			w[l].push({
				"gtm.start": new Date().getTime(),
				event: "gtm.js",
			});
			var f = d.getElementsByTagName(s)[0],
				j = d.createElement(s),
				dl = l != "dataLayer" ? "&l=" + l : "";
			j.async = true;
			j.src = "https://www.googletagmanager.com/gtm.js?id=" + i + dl;
			f.parentNode.insertBefore(j, f);
		})(window, document, "script", "dataLayer", "GTM-55ZRVWSR");
	</script>
	<!-- End Google Tag Manager -->
</head>

<body>
	<!-- header -->
	<header class="c-header js-header" observer-animation="cssClass" observer-animation-classes="animateIn">
		<nav aria-label="BBPS Header Navigation" class="c-header__nav">
			<div class="c-header__lhs">
				<a href="" aria-label="Home"><img class="c-header__logo" alt="Bharat BillPay Logo" width="100" height="33" src="assets/images/vectors/icon_logo.svg" /></a>
				<a href="" aria-label="Home">
					<img alt="Bharat BillPay Logo" class="c-header__harPaymentLogo" src="assets/images/empty.webp" data-image data-desktop-src="assets/images/vectors/icon_d_harPaymentDigital.svg" data-mobile-src="assets/images/vectors/icon_d_harPaymentDigital.svg" />
				</a>
			</div>
			<ul class="c-header__navList js-header__menu">
				<li role="presentation" class="c-header__navItem">
					<a class="js-header__menuLink" href="#agent-locator-search">Agent Locator Search</a>
				</li>
				<li role="presentation" class="c-header__navItem">
					<a class="js-header__menuLink" href="#faqs">FAQs</a>
				</li>
				<li role="presentation" class="c-header__navItem">
					<a class="js-header__menuLink" href="#support-centre">Support centre</a>
				</li>
			</ul>
			<div class="c-header__rhs">
				<a href="support/raise-complaint-customer/" class="c-btn -fill anim-stagger-3 anim-hoverArrowContainer">
					<span class="c-btn__text">Get started</span>
				</a>
				<button type="button" class="c-header__menuBtn" aria-label="toggle menu">
					<svg aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
						<path d="M2 5V7H22V5H2ZM2 11V13H22V11H2ZM2 17V19H22V17H2Z" fill="black" />
					</svg>
				</button>
			</div>
		</nav>
	</header>
	<div class="c-hamburgerMenu js-hamburgerMenu">
		<div class="c-hamburgerMenu_container">
			<div class="c-hamburgerMenu_Mob isBelow1024">
				<div class="c-hamburgerMenu_lhs__logo">
					<a href="" aria-label="Home"><img alt="Bharat BillPay Logo" class="c-header__logo" width="100" height="33" src="assets/images/vectors/icon_logo.svg" /></a>
					<a href="" aria-label="Home">
						<img alt="Bharat BillPay Logo" class="c-header__harPaymentLogo" src="assets/images/empty.webp" data-image data-desktop-src="assets/images/vectors/icon_d_harPaymentDigital.svg" data-mobile-src="assets/images/vectors/icon_d_harPaymentDigital.svg" />
					</a>
				</div>
				<button type="button" class="js-closeMenu mobMenu">
					<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
						<path d="M9.85259e-05 2.21585L1.36377 0.858643L15.0005 14.4308L13.6368 15.788L9.85259e-05 2.21585Z" fill="#1e1e1c" />
						<path d="M15.0014 2.21585L13.6377 0.858643L0.000985428 14.4308L1.36466 15.788L15.0014 2.21585Z" fill="#1e1e1c" />
					</svg>
				</button>
			</div>
			<div class="c-hamburgerMenu_lhs">
				<div class="c-hamburgerMenu_lhs__logo isAbove1023">
					<a href="" aria-label="Home" class="isAbove1023"><img alt="Bharat BillPay Logo" class="c-header__logo" width="100" height="33" src="assets/images/vectors/icon_logo.svg" /></a>
					<a href="" aria-label="Home" class="isAbove1023">
						<img alt="Bharat BillPay Logo" class="c-header__harPaymentLogo" src="assets/images/empty.webp" data-image data-desktop-src="assets/images/vectors/icon_d_harPaymentDigital.svg" data-mobile-src="assets/images/vectors/icon_m_harPaymentDigital.svg" />
					</a>
				</div>
				<ul class="c-hamburgerMenu_lhs__navList">
					<li role="presentation" class="c-hamburgerMenu_lhs__navItem anim-stagger-1">
						<a class="js-header__menuLink" href="billers/" data-item="billers">Billers</a>
					</li>
					<li role="presentation" class="c-hamburgerMenu_lhs__navItem anim-stagger-2">
						<a class="js-header__menuLink" href="operating-units/" data-item="operating units">Operating Units</a>
					</li>
					<li role="presentation" class="c-hamburgerMenu_lhs__navItem anim-stagger-3">
						<a class="js-header__menuLink" href="customers/" data-item="customers">Customers</a>
					</li>
					<li role="presentation" class="c-hamburgerMenu_lhs__navItem anim-stagger-4">
						<a class="js-header__menuLink" href="developers/" data-item="developers">Developers</a>
					</li>
				</ul>
			</div>
			<div class="c-hamburgerMenu_rhs">
				<button type="button" class="c-hamburgerMenu_rhs__closeIcon js-closeMenu isAbove1023">
					<svg xmlns="http://www.w3.org/2000/svg" width="21" height="20" viewBox="0 0 21 20" fill="none">
						<path d="M0.000135702 1.81818L1.81836 0L20.0006 18.1818L18.1824 19.9999L0.000135702 1.81818Z" fill="white" />
						<path d="M20.0018 1.81818L18.1836 0L0.00135938 18.1818L1.81958 19.9999L20.0018 1.81818Z" fill="white" />
					</svg>
				</button>
				<div class="c-hamburgerMenu_rhs__bg">
					<svg width="798" height="666" viewBox="0 0 798 666" fill="none" xmlns="http://www.w3.org/2000/svg">
						<g clip-path="url(#clip0_1_20)">
							<path opacity="0.2" d="M18 0C17.9998 77 111.015 166.5 180.508 213C250 259.5 342.008 316.5 364.004 330C386 343.5 457.008 388.5 375.508 384C251.816 377.17 26.0075 339 95.5075 486C165.008 633 408.508 652.5 498.508 647.5C588.508 642.5 699.008 605.5 816.508 514.5" stroke="url(#paint0_linear_1_20)" stroke-width="35" />
						</g>
						<defs>
							<linearGradient id="paint0_linear_1_20" x1="18" y1="44.5" x2="796.5" y2="519" gradientUnits="userSpaceOnUse">
								<stop stop-color="white" />
								<stop offset="1" stop-color="white" stop-opacity="0.06" />
							</linearGradient>
							<clipPath id="clip0_1_20">
								<rect width="798" height="666" fill="white" />
							</clipPath>
						</defs>
					</svg>
				</div>
				<div class="c-hamburgerMenu_rhs__list">
					<ul class="c-hamburgerMenu_rhs__navList">
						<li role="presentation" class="c-hamburgerMenu_rhs__navItem anim-stagger-1">
							<a class="js-header__menuLink" href="solutions/">Solutions</a>
						</li>
						<li role="presentation" class="c-hamburgerMenu_rhs__navItem anim-stagger-2">
							<a class="js-header__menuLink" href="categories/">Categories</a>
						</li>
						<li role="presentation" class="c-hamburgerMenu_rhs__navItem anim-stagger-3">
							<a class="js-header__menuLink" href="circulars/">Circulars</a>
						</li>
						<li role="presentation" class="c-hamburgerMenu_rhs__navItem anim-stagger-4">
							<a class="js-header__menuLink" href="statistics/">Statistics</a>
						</li>
						<li role="presentation" class="c-hamburgerMenu_rhs__navItem anim-stagger-5">
							<a class="js-header__menuLink" href="media-room/">Media Room</a>
						</li>
						<li role="presentation" class="c-hamburgerMenu_rhs__navItem anim-stagger-6">
							<a class="js-header__menuLink" href="resources/">Resources</a>
						</li>
						<li role="presentation" class="c-hamburgerMenu_rhs__navItem anim-stagger-7">
							<a class="js-header__menuLink" href="brand-centre/">Brand Centre</a>
						</li>
						<li role="presentation" class="c-hamburgerMenu_rhs__navItem anim-stagger-8">
							<a class="js-header__menuLink" href="about/">About</a>
						</li>
						<li role="presentation" class="c-hamburgerMenu_rhs__navItem anim-stagger-9">
							<a class="js-header__menuLink" href="corporate-governance/">Corporate Governance</a>
						</li>
						<li role="presentation" class="c-hamburgerMenu_rhs__navItem anim-stagger-10">
							<a class="js-header__menuLink" href="support/">Support</a>
						</li>
					</ul>
					<ul class="c-hamburgerMenu_rhs__navList">
						<li role="presentation" class="c-hamburgerMenu_rhs__navItem anim-stagger-11">
							<a class="js-header__menuLink" href="legal/copyrights/">Copyrights</a>
						</li>
						<li role="presentation" class="c-hamburgerMenu_rhs__navItem anim-stagger-12">
							<a class="js-header__menuLink" href="legal/privacy-security-policy/">Policies</a>
						</li>
						<li role="presentation" class="c-hamburgerMenu_rhs__navItem anim-stagger-13">
							<a class="js-header__menuLink" href="legal/disclaimer/">Disclaimer</a>
						</li>
						<li role="presentation" class="c-hamburgerMenu_rhs__navItem anim-stagger-14">
							<a class="js-header__menuLink" href="sitemap/">Sitemap</a>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	<div class="c-pageMenu js-pageMenu isBelow1024">
		<button type="button" class="c-pageMenu__activeLink js-pageMenu__toggleBtn" aria-expanded="false">
			<span>Agent Locator Search</span>
			<svg aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg" width="20" height="21" viewBox="0 0 20 21" fill="none">
				<path d="M10 0.5C4.49 0.5 0 4.99 0 10.5C0 16.01 4.49 20.5 10 20.5C15.51 20.5 20 16.01 20 10.5C20 4.99 15.51 0.5 10 0.5ZM14.06 9.77L10.53 13.3C10.38 13.45 10.19 13.52 10 13.52C9.81 13.52 9.62 13.45 9.47 13.3L5.94 9.77C5.65 9.48 5.65 9 5.94 8.71C6.23 8.42 6.71 8.42 7 8.71L10 11.71L13 8.71C13.29 8.42 13.77 8.42 14.06 8.71C14.35 9 14.35 9.47 14.06 9.77Z" fill="#40D0CB" />
			</svg>
		</button>
		<ul class="c-pageMenu__links">
			<li><a class="c-pageMenu__link js-pageMenu__link" href="#agent-locator-search">Agent Locator Search</a></li>
			<li><a class="c-pageMenu__link js-pageMenu__link" href="#faqs">FAQs</a></li>
			<li><a class="c-pageMenu__link js-pageMenu__link" href="#support-centre">Support centre</a></li>
		</ul>
	</div>
	<div class="c-scrollProgress js-scrollProgress"></div>
	<main>

		<section id="agent-locator-search" class="agentSearch anim-stagger-1" observer-animation="cssClass" observer-animation-classes="animateIn">
			<div class="agentSearch__container">
				<div class="agentSearch__wrap --forModalAdjust">
					<div class="agentSearch__col-lft">
						<div class="agentSearch__content">
							<h2 class="agentSearch__content-heading">Agent Locator</h2>
							<div class="agentSearch__content-wrap">
								<div class="agentSearch__content-input">
									<!--Search icon-->
									<svg xmlns="http://www.w3.org/2000/svg" class="agentSearch__icon" width="20" height="20" viewBox="0 0 20 20" fill="none">
										<g clip-path="url(#a)">
											<path stroke="#5F5F5F" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="m18.333 18.333-1.667-1.666m-7.083.833a7.918 7.918 0 1 0 0-15.836 7.918 7.918 0 0 0 0 15.836Z" />
										</g>
										<defs>
											<clipPath id="a">
												<path fill="#fff" d="M0 0h20v20H0z" />
											</clipPath>
										</defs>
									</svg>
									<!--Input field-->
									<input type="tel" maxlength="6" aria-label="Search by PIN code" class="agentSearch__input js-agentSearch" placeholder="Search by PIN code">
									<!--Submit button-->
									<button type="button" aria-label="Submit" class="-underlineText agentSearch__input-submit c-btn__text js-submitInput">Submit</button>
									<!--Clear button-->
									<button type="button" aria-label="Clear" class="agentSearch__input-clear js-clearInput">
										<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14" fill="none">
											<path d="M1 13L13 1" stroke="#B5B5B5" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
											<path d="M13 13L1 1" stroke="#B5B5B5" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
										</svg>
									</button>
								</div>
								<div class = "c-fav__filter__wrap">
									<button type="button" aria-label="View favorites" class="agentSearch__content-favBtn js-viewFavList">
										<svg xmlns="http://www.w3.org/2000/svg" width="18" height="16" viewBox="0 0 18 16" fill="none">
											<path stroke="#5F5F5F" stroke-width="1.5" d="m8.47335 3.06946.61686.89195.61685-.89195C10.4923 1.93398 11.7201 1.25 12.8789 1.25 15.1482 1.25 17 3.12722 17 5.53106c0 1.02162-.5085 2.65399-1.5857 4.00042-.9353 1.16922-2.4376 2.40302-3.772 3.39002-.6598.4879-1.2649.9057-1.71906 1.2149-.10351.0704-.20179.137-.29115.1976-.10269.0695-.19361.1311-.26716.1815-.06995.0478-.13244.0911-.18202.1269-.0014.001-.00299.0021-.00475.0034-.01105.0079-.02877.0207-.04987.0368-.05646.0286-.09451.0466-.12829.0597-.03378-.0131-.07183-.0311-.12829-.0597-.0211-.0161-.03882-.0289-.04987-.0368-.00176-.0013-.00335-.0024-.00475-.0034-.04958-.0358-.11207-.0791-.18202-.1269-.07356-.0504-.1645-.112-.26721-.1816-.08935-.0605-.18761-.1271-.2911-.1975-.45413-.3092-1.05927-.727-1.71906-1.2149-1.33443-.987-2.83667-2.2208-3.77205-3.39002C1.50851 8.18505 1 6.55268 1 5.53106 1 3.13634 2.93313 1.25 5.12113 1.25c1.35465 0 2.57672.69812 3.35222 1.81946Z" />
										</svg>
									</button>
									<!-- <button type="button" aria-label="Filter" class="agentSearch__content-filterBtn js-filterBtn">
										<svg xmlns="http://www.w3.org/2000/svg" width="16" height="12" fill="none">
											<path fill="#5F5F5F" d="M.7504 9.5005c0-.41.34-.75.75-.75h6.9c.41 0 .75.34.75.75s-.34.75-.75.75h-6.9c-.41 0-.75-.34-.75-.75Zm11.0496 0c0-.41.34-.75.75-.75h1.95c.41 0 .75.34.75.75s-.34.75-.75.75h-1.95c-.41 0-.75-.34-.75-.75Z" />
											<path fill="#5F5F5F" d="M7.75 9.5034c0-1.3806 1.1194-2.5 2.5-2.5s2.5 1.1194 2.5 2.5-1.1194 2.5-2.5 2.5-2.5-1.1268-2.5-2.5Zm7.4996-7.0039c0 .41-.34.75-.75.75h-6.9c-.41 0-.75-.34-.75-.75s.34-.75.75-.75h6.9c.41 0 .75.34.75.75Zm-11.0496 0c0 .41-.34.75-.75.75H1.5c-.41 0-.75-.34-.75-.75s.34-.75.75-.75h1.95c.41 0 .75.34.75.75Z" />
											<path fill="#5F5F5F" d="M8.25 2.4966c0 1.3806-1.1194 2.5-2.5 2.5s-2.5-1.1194-2.5-2.5 1.1194-2.5 2.5-2.5 2.5 1.1269 2.5 2.5Z" />
										</svg>
									</button> -->
								</div>
							</div>
							<button type="button" class="agentSearch__content-nearBtn js-enableLocation">Enable device location to find Agents near you</button>
						</div>
					</div>
					<div class="agentSearch__col-rgt"></div>
				</div>
				<div class="agentSearch__wrap --orderChange">
					<div class="agentSearch__col-lft">

						<!-- Search Listing -->
						<div class="agentSearch__listing">
							<!-- Favourite agents show only modal favlist-->
							<h2 class="favModal__title">
								Favourite agents
								<button type="button" class="favModal__close js-favCloseBtn">								
									<svg width="17" height="17" viewBox="0 0 17 17" fill="none" xmlns="http://www.w3.org/2000/svg">
									<path d="M1 15.75L15.5 1.25" stroke="#1E1E1C" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
									<path d="M1 15.75L15.5 1.25" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
									<path d="M1 15.75L15.5 1.25" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
									<path d="M1 15.75L15.5 1.25" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
									<path d="M15.5 15.75L1 1.25" stroke="#1E1E1C" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
									<path d="M15.5 15.75L1 1.25" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
									<path d="M15.5 15.75L1 1.25" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
									<path d="M15.5 15.75L1 1.25" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
									</svg>
								</button>
							</h2>

							<p class="agentSearch__listing-heading js-nearHeading"></p>
							<div class="agentSearch__listing-listWrap js-listWrap">
								<ul class="agentSearch__listing-list js-listingList">
									<!-- Searched Item -->

								</ul>
								<ul class="agentSearch__listing-list js-listingList-favourate">
									<!-- Searched Item -->
								</ul>
							</div>
							
							<!-- load more -->
							<button type="button" class="agentSearch__listing-loadMore js-loadMore c-btn -outline anim-hoverArrowContainer anim-stagger-3">Load more</button>
							

							<!-- Listing not found -->
							<div class="agentSearch__listing-notFound js-nofavFound">
								<span class="agentSearch__listing-notFoundIcon">
								<svg width="60" height="60" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
									<g clip-path="url(#clip0_12905_6353)">
									<path d="M55.6191 53.76L43.1591 41.3C47.0252 36.8838 49.0234 31.1378 48.7316 25.2757C48.4397 19.4137 45.8808 13.8945 41.5952 9.88415C37.3096 5.87377 31.633 3.6862 25.7645 3.78351C19.896 3.88082 14.295 6.25539 10.1448 10.4056C5.99453 14.5559 3.61995 20.1568 3.52264 26.0254C3.42533 31.8939 5.61291 37.5705 9.62328 41.8561C13.6337 46.1416 19.1528 48.7006 25.0149 48.9924C30.877 49.2842 36.623 47.2861 41.0391 43.42L53.4991 55.88L55.6191 53.76ZM6.93913 26.68C6.93121 22.8484 8.06043 19.1006 10.1838 15.9112C12.3072 12.7218 15.3292 10.2341 18.8672 8.76328C22.4053 7.29242 26.3002 6.90448 30.0589 7.64859C33.8175 8.3927 37.2708 10.2354 39.9816 12.9433C42.6923 15.6513 44.5386 19.1027 45.2866 22.8606C46.0346 26.6185 45.6507 30.5138 44.1835 34.0533C42.7163 37.5929 40.2318 40.6175 37.0446 42.7442C33.8573 44.8708 30.1107 46.0039 26.2791 46C21.1565 45.9894 16.2465 43.9512 12.6224 40.3308C8.9983 36.7105 6.95498 31.8026 6.93913 26.68Z" fill="#231F20"/>
									<path d="M43.0602 6.47998H34.6602V14.88H43.0602V6.47998Z" fill="#FFE27A"/>
									<path d="M25.5567 21.7105L26.7903 23.4937L28.0239 21.7105C28.9933 20.3092 30.4872 19.5 31.8433 19.5C34.5792 19.5 36.84 21.7642 36.84 24.7081C36.84 25.9438 36.209 28.0123 34.8348 29.7295C33.6304 31.2346 31.6717 32.8477 29.8971 34.1598C29.0246 34.8049 28.2236 35.3578 27.6203 35.7684C27.4848 35.8606 27.3541 35.9491 27.2347 36.03C27.0962 36.1238 26.9729 36.2073 26.8746 36.2746C26.8009 36.325 26.7311 36.3732 26.67 36.4164C26.6089 36.3732 26.5391 36.325 26.4654 36.2746C26.3671 36.2073 26.2437 36.1238 26.1053 36.03C25.9858 35.9491 25.8552 35.8606 25.7197 35.7684C25.1164 35.3578 24.3154 34.8049 23.4429 34.1598C21.6683 32.8477 19.7096 31.2346 18.5052 29.7295C17.131 28.0123 16.5 25.9438 16.5 24.7081C16.5 21.7824 18.8633 19.5 21.4967 19.5C23.1243 19.5 24.6068 20.3374 25.5567 21.7105Z" stroke="#1E1E1C" stroke-width="3"/>
									<path d="M25.5567 21.7105L26.7903 23.4937L28.0239 21.7105C28.9933 20.3092 30.4872 19.5 31.8433 19.5C34.5792 19.5 36.84 21.7642 36.84 24.7081C36.84 25.9438 36.209 28.0123 34.8348 29.7295C33.6304 31.2346 31.6717 32.8477 29.8971 34.1598C29.0246 34.8049 28.2236 35.3578 27.6203 35.7684C27.4848 35.8606 27.3541 35.9491 27.2347 36.03C27.0962 36.1238 26.9729 36.2073 26.8746 36.2746C26.8009 36.325 26.7311 36.3732 26.67 36.4164C26.6089 36.3732 26.5391 36.325 26.4654 36.2746C26.3671 36.2073 26.2437 36.1238 26.1053 36.03C25.9858 35.9491 25.8552 35.8606 25.7197 35.7684C25.1164 35.3578 24.3154 34.8049 23.4429 34.1598C21.6683 32.8477 19.7096 31.2346 18.5052 29.7295C17.131 28.0123 16.5 25.9438 16.5 24.7081C16.5 21.7824 18.8633 19.5 21.4967 19.5C23.1243 19.5 24.6068 20.3374 25.5567 21.7105Z" stroke="black" stroke-opacity="0.2" stroke-width="3"/>
									<path d="M25.5567 21.7105L26.7903 23.4937L28.0239 21.7105C28.9933 20.3092 30.4872 19.5 31.8433 19.5C34.5792 19.5 36.84 21.7642 36.84 24.7081C36.84 25.9438 36.209 28.0123 34.8348 29.7295C33.6304 31.2346 31.6717 32.8477 29.8971 34.1598C29.0246 34.8049 28.2236 35.3578 27.6203 35.7684C27.4848 35.8606 27.3541 35.9491 27.2347 36.03C27.0962 36.1238 26.9729 36.2073 26.8746 36.2746C26.8009 36.325 26.7311 36.3732 26.67 36.4164C26.6089 36.3732 26.5391 36.325 26.4654 36.2746C26.3671 36.2073 26.2437 36.1238 26.1053 36.03C25.9858 35.9491 25.8552 35.8606 25.7197 35.7684C25.1164 35.3578 24.3154 34.8049 23.4429 34.1598C21.6683 32.8477 19.7096 31.2346 18.5052 29.7295C17.131 28.0123 16.5 25.9438 16.5 24.7081C16.5 21.7824 18.8633 19.5 21.4967 19.5C23.1243 19.5 24.6068 20.3374 25.5567 21.7105Z" stroke="black" stroke-opacity="0.2" stroke-width="3"/>
									<path d="M25.5567 21.7105L26.7903 23.4937L28.0239 21.7105C28.9933 20.3092 30.4872 19.5 31.8433 19.5C34.5792 19.5 36.84 21.7642 36.84 24.7081C36.84 25.9438 36.209 28.0123 34.8348 29.7295C33.6304 31.2346 31.6717 32.8477 29.8971 34.1598C29.0246 34.8049 28.2236 35.3578 27.6203 35.7684C27.4848 35.8606 27.3541 35.9491 27.2347 36.03C27.0962 36.1238 26.9729 36.2073 26.8746 36.2746C26.8009 36.325 26.7311 36.3732 26.67 36.4164C26.6089 36.3732 26.5391 36.325 26.4654 36.2746C26.3671 36.2073 26.2437 36.1238 26.1053 36.03C25.9858 35.9491 25.8552 35.8606 25.7197 35.7684C25.1164 35.3578 24.3154 34.8049 23.4429 34.1598C21.6683 32.8477 19.7096 31.2346 18.5052 29.7295C17.131 28.0123 16.5 25.9438 16.5 24.7081C16.5 21.7824 18.8633 19.5 21.4967 19.5C23.1243 19.5 24.6068 20.3374 25.5567 21.7105Z" stroke="black" stroke-opacity="0.2" stroke-width="3"/>
									</g>
									<defs>
									<clipPath id="clip0_12905_6353">
									<rect width="60" height="60" fill="white"/>
									</clipPath>
									</defs>
								</svg>
								</span>
								<h2 class="agentSearch__listing-notFoundTitle">No Favourites added</h2>
								<p class="agentSearch__listing-notFoundText">Find and add agents as favourites to see them here</p>
							</div>

							<!-- Search timer limits-->
							<div class="agentSearch__listing-timer	js-timer">
								<div id="revese-timer" data-start-timer="false"></div>
								<p class="agentSearch__listing-timerPara">
									You can only make 10 searches per minute.
								</p>
								<p class="agentSearch__listing-timerDesc">
									Please wait while we refresh our database so you can resume your search.
								</p>
							</div>

							<!-- Not REcord Found -->
							<div class="agentSearch__notFound js-noRecordFound">
								<span class="agentSearch__notFoundIcon">
									<svg width="60" height="60" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
										<g clip-path="url(#clip0_12355_13615)">
											<path d="M27.7793 13.92H24.7793V30.98H27.7793V13.92Z" fill="black" />
											<path d="M26.2801 39.42C27.4951 39.42 28.4801 38.435 28.4801 37.22C28.4801 36.005 27.4951 35.02 26.2801 35.02C25.0651 35.02 24.0801 36.005 24.0801 37.22C24.0801 38.435 25.0651 39.42 26.2801 39.42Z" fill="black" />
											<path d="M55.6191 53.76L43.1591 41.3C47.0252 36.8838 49.0234 31.1378 48.7316 25.2757C48.4397 19.4137 45.8808 13.8945 41.5952 9.88415C37.3096 5.87377 31.633 3.6862 25.7645 3.78351C19.896 3.88082 14.295 6.25539 10.1448 10.4056C5.99453 14.5559 3.61995 20.1568 3.52264 26.0254C3.42533 31.8939 5.61291 37.5705 9.62328 41.8561C13.6337 46.1416 19.1528 48.7006 25.0149 48.9924C30.877 49.2842 36.623 47.2861 41.0391 43.42L53.4991 55.88L55.6191 53.76ZM6.93913 26.68C6.93121 22.8484 8.06043 19.1006 10.1838 15.9112C12.3072 12.7218 15.3292 10.2341 18.8672 8.76328C22.4053 7.29242 26.3002 6.90448 30.0589 7.64859C33.8175 8.3927 37.2708 10.2354 39.9816 12.9433C42.6923 15.6513 44.5386 19.1027 45.2866 22.8606C46.0346 26.6185 45.6507 30.5138 44.1835 34.0533C42.7163 37.5929 40.2318 40.6175 37.0446 42.7442C33.8573 44.8708 30.1107 46.0039 26.2791 46C21.1565 45.9894 16.2465 43.9512 12.6224 40.3308C8.9983 36.7105 6.95498 31.8026 6.93913 26.68Z" fill="#231F20" />
											<path d="M43.0602 6.47998H34.6602V14.88H43.0602V6.47998Z" fill="#FFE27A" />
										</g>
										<defs>
											<clipPath id="clip0_12355_13615">
												<rect width="60" height="60" fill="white" />
											</clipPath>
										</defs>
									</svg>
								</span>
								<h2 class="agentSearch__notFoundTitle">No agents found</h2>
								<ul class="agentSearch__notFoundList">
									<li>Check your spelling</li>
									<li>Try other keywords</li>
								</ul>
								<button class="c-btn -outline agentSearch__notFoundBtn anim-hoverArrowContainer">
									<span class="c-btn__text">Make payment online</span>
								</button>
							</div>

						</div>

						<!-- Loader -->
						<div class="agentSearch__loaderWrap js-loaderWrap">
							<span class="agentSearch__loader js-loader"></span>
						</div>


						<!-- Filter Modal -->
						<div class="filterModal js-filterModal">
							<div class="filterModal__wrap">
								<h2 class="filterModal__title">
									Filters
									<button type="button" class="filterModal__close js-filterCloseBtn">
										<svg xmlns="http://www.w3.org/2000/svg" width="16" height="18" viewBox="0 0 16 18" fill="none">
											<path stroke="#1E1E1C" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M1 16.5L16 1.5" />
											<path stroke="#000" stroke-linecap="round" stroke-linejoin="round" stroke-opacity=".2" stroke-width="1.5" d="M1 16.5 16 1.5M1 16.5 16 1.5M1 16.5 16 1.5" />
											<path stroke="#1E1E1C" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M16 16.5L1 1.5" />
											<path stroke="#000" stroke-linecap="round" stroke-linejoin="round" stroke-opacity=".2" stroke-width="1.5" d="M16 16.5 1 1.5M16 16.5 1 1.5M16 16.5 1 1.5" />
										</svg>
									</button>
								</h2>
								<!-- Filter Dropdowns -->
								<div class="section__filterDropdowns">
									<!-- State Select -->
									<div id="stateSelect" class="section__filterDropdown c-select js-select js-stateSelect">
										<span class="c-selectLabel a11y-visuallyHidden" id="stateLabel">State</span>
										<div class="c-selectWrapper">
											<select name="state" id="state" class="c-selectNative js-select__native" aria-labelledby="stateLabel">
												<option value="state" selected>State</option>
												<option value="Andhra Pradesh">Andhra Pradesh</option>
												<option value="Assam">Assam</option>
												<option value="Bihar">Bihar</option>
												<option value="Chhattisgarh">Chhattisgarh</option>
												<option value="Delhi">Delhi</option>
											</select>
											<!-- Hide the custom select from AT (e.g. SR) using aria-hidden -->
											<div class="c-selectCustom js-select__custom" aria-hidden="true">
												<div class="c-selectCustom__trigger js-select__customTrigger">State</div>
												<div class="c-selectCustom__options">
													<div class="c-selectCustom__optionsInner js-select__customOptions">
														<div class="c-selectCustom__option" data-value="Andhra Pradesh">Andhra Pradesh</div>
														<div class="c-selectCustom__option" data-value="Assam">Assam</div>
														<div class="c-selectCustom__option" data-value="Bihar">Bihar</div>
														<div class="c-selectCustom__option" data-value="Chhattisgarh">Chhattisgarh</div>
														<div class="c-selectCustom__option" data-value="Delhi">Delhi</div>
													</div>
												</div>
											</div>
										</div>
									</div>
									<!-- City Select -->
									<div id="citySelect" class="section__filterDropdown c-select js-select js-citySelect">
										<span class="c-selectLabel a11y-visuallyHidden" id="cityLabel">City</span>
										<div class="c-selectWrapper">
											<select name="city" id="city" class="c-selectNative js-select__native" aria-labelledby="cityLabel">
												<option value="City" selected>City</option>
												<option value="Mumbai">Mumbai</option>
												<option value="New Delhi">New Delhi</option>
											</select>
											<!-- Hide the custom select from AT (e.g. SR) using aria-hidden -->
											<div class="c-selectCustom js-select__custom" aria-hidden="true">
												<div class="c-selectCustom__trigger js-select__customTrigger">City</div>
												<div class="c-selectCustom__options">
													<div class="c-selectCustom__optionsInner js-select__customOptions">
														<div class="c-selectCustom__option" data-value="City">City</div>
														<div class="c-selectCustom__option" data-value="Mumbai">Mumbai</div>
														<div class="c-selectCustom__option" data-value="New Delhi">New Delhi</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							<!-- Filter Button Group -->
							<div class="filterModal__btnGroup">
								<button class="c-btn -outline anim-hoverArrowContainer">
									<span class="c-btn__text">Clear filter(s)</span>
								</button>
								<button class="c-btn -fill anim-hoverArrowContainer">
									<span class="c-btn__text">Apply</span>
								</button>
							</div>
						</div>

					</div>
					<div class="agentSearch__col-rgt">
						<div class="agentSearch__map">
							<div id="map"></div>
						</div>
					</div>
				</div>
			</div>
		</section>

		<!-- c-faqs -->
		<section id="faqs" class="section c-faqs anim-stagger-1" observer-animation="cssClass" observer-animation-classes="animateIn">
			<h2 class="c-faqs__heading">FAQs</h2>
			<div class="c-faqs__list">
				<div class="c-faqs__faq">
					<h2 class="c-faqs__faqHeading js-accordionHeading">
						<button aria-expanded="false" id="faq1">
							Who are Agents?
							<svg aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg" width="31" height="30" viewBox="0 0 31 30" fill="none">
								<path d="M8 15H23" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
								<path d="M15.5 22.5V7.5" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
							</svg>
						</button>
					</h2>
					<div class="c-faqs__faqContent" role="region" aria-labelledby="faq1">
						<p>Customers’ payment information will be collected at the Customer Operating Unit’s end. Details such as card number, account number etc. will not be passed to other third party platforms. Only the payment mode will be shared with the Biller/Biller Operating Unit/Bharat BillPay Central Unit. </p>
					</div>
				</div>
				<div class="c-faqs__faq">
					<h2 class="c-faqs__faqHeading js-accordionHeading">
						<button id="faq2" aria-expanded="false">
							Who supervises Agents?
							<svg aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg" width="31" height="30" viewBox="0 0 31 30" fill="none">
								<path d="M8 15H23" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
								<path d="M15.5 22.5V7.5" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
							</svg>
						</button>
					</h2>
					<div class="c-faqs__faqContent" role="region" aria-labelledby="faq2">
						<p>
							Since thousands of Agents are required to cater to Customers, Bharat BillPay partners with banks and non-bank institutions. They are responsible for onboarding Agents in their respective locations and act as intermediaries between Agents and Bharat BillPay.
						</p>
					</div>
				</div>
				<div class="c-faqs__faq">
					<h2 class="c-faqs__faqHeading js-accordionHeading">
						<button id="faq2" aria-expanded="false">
							How do I know if my payment to an Agent has been recognised?
							<svg aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg" width="31" height="30" viewBox="0 0 31 30" fill="none">
								<path d="M8 15H23" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
								<path d="M15.5 22.5V7.5" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
							</svg>
						</button>
					</h2>
					<div class="c-faqs__faqContent" role="region" aria-labelledby="faq2">
						<p>Customers’ payment information will be collected at the Customer Operating Unit’s end. Details such as card number, account number etc. will not be passed to other third party platforms. Only the payment mode will be shared with the Biller/Biller Operating Unit/Bharat BillPay Central Unit. </p>
					</div>
				</div>
				<div class="c-faqs__faq">
					<h2 class="c-faqs__faqHeading js-accordionHeading">
						<button id="faq2" aria-expanded="false">
							Who can I connect with in case of any problems with my bill payment to an agent?
							<svg aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg" width="31" height="30" viewBox="0 0 31 30" fill="none">
								<path d="M8 15H23" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
								<path d="M15.5 22.5V7.5" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
							</svg>
						</button>
					</h2>
					<div class="c-faqs__faqContent" role="region" aria-labelledby="faq2">
						<p>Customers’ payment information will be collected at the Customer Operating Unit’s end. Details such as card number, account number etc. will not be passed to other third party platforms. Only the payment mode will be shared with the Biller/Biller Operating Unit/Bharat BillPay Central Unit. </p>
					</div>
				</div>
				<div class="c-faqs__faq">
					<h2 class="c-faqs__faqHeading js-accordionHeading">
						<button id="faq2" aria-expanded="false">
							What kind of bills can I pay via an Agent?
							<svg aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg" width="31" height="30" viewBox="0 0 31 30" fill="none">
								<path d="M8 15H23" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
								<path d="M15.5 22.5V7.5" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
							</svg>
						</button>
					</h2>
					<div class="c-faqs__faqContent" role="region" aria-labelledby="faq2">
						<p>Customers’ payment information will be collected at the Customer Operating Unit’s end. Details such as card number, account number etc. will not be passed to other third party platforms. Only the payment mode will be shared with the Biller/Biller Operating Unit/Bharat BillPay Central Unit. </p>
					</div>
				</div>
			</div>
		</section>

		<!-- Support centre-->
		<section id="support-centre" class="section supportCentre center" observer-animation="cssClass" observer-animation-classes="animateIn">
			<div class="supportCentre__rhs">
				<div class="supportCentre__contentWrap">
					<h2 class="supportCentre__heading anim-stagger-1">Support centre</h2>
					<h3 class="supportCentre__label anim-stagger-2">
						Facing trouble finding the right Agent or have any other query?
					</h3>
				</div>
				<a href="support/" class="supportCentre__btn c-btn -outline anim-hoverArrowContainer anim-stagger-3">
					<span class="c-btn__text"> Get in touch </span>
					<img width="15" height="15" class="anim-hoverArrow" alt="arrow icon" src="assets/images/vectors/icons/icon_arrowright.svg" />
				</a>
			</div>
		</section>

		<!-- Nudge pop up -->
		<div class="c-loginNudge js-savedAsFavourite">
			<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
				<rect width="20" height="20" rx="10" fill="#7AC51C" />
				<path d="M7.375 10.125L9.25 12L13.625 7.625" stroke="white" stroke-linecap="round" stroke-linejoin="round" />
			</svg>
			<p id="toastMessage">Saved as favourite</p>
		</div>

		<!-- c-footer -->
		<footer class="c-footer js-footer" role="contentinfo" aria-labelledby="c-footer__assistiveLabel">
			<div class="c-footer__content">
				<h2 class="a11y-visuallyHidden" id="c-footer__assistiveLabel">BBPS Footer</h2>
				<nav role="navigation" aria-label="BBPS Footer Navigation" class="c-footer__nav">
					<ul class="c-footer__columns js-footerColumns">
						<li class="c-footer__column -mobileAccordion">
							<div class="c-footer__columnList">
								<span class="c-footer__titleTextHead">For Customers</span>
								<button type="button" class="c-footer__navBtn js-navBtn" aria-expanded="false" data-nav-links="#customersLinks">
									<span class="c-footer__titleText">For Customers</span>
									<svg aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg" width="31" height="30" viewBox="0 0 31 30" fill="none">
										<path d="M8 15H23" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
										<path d="M15.5 22.5V7.5" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
									</svg>
								</button>
								<ul id="customersLinks" class="c-footer__navLinks">
									<li role="presentation" class="c-footer__navLink">
										<a href="customers/">Customers</a>
									</li>
									<li role="presentation" class="c-footer__navLink">
										<a href="customers/payment-outlets/index.php?tab-id=digital">Find payment channels</a>
									</li>
									<li role="presentation" class="c-footer__navLink">
										<a href="customer-insights/">Customer Insights</a>
									</li>
									<li role="presentation" class="c-footer__navLink">
										<a href="support/raise-complaint-customer/">Raise a complaint</a>
									</li>
								</ul>
							</div>
							<div class="c-footer__columnList">
								<span class="c-footer__titleTextHead">For Partners</span>
								<button type="button" class="c-footer__navBtn js-navBtn" aria-expanded="false" data-nav-links="#partnerLinks">
									<span class="c-footer__titleText">For Partners</span>
									<svg aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg" width="31" height="30" viewBox="0 0 31 30" fill="none">
										<path d="M8 15H23" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
										<path d="M15.5 22.5V7.5" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
									</svg>
								</button>
								<ul id="partnerLinks" class="c-footer__navLinks">
									<li role="presentation" class="c-footer__navLink">
										<a href="billers/">Billers</a>
									</li>
									<li role="presentation" class="c-footer__navLink">
										<a href="operating-units/">Operating Units</a>
									</li>
									<li role="presentation" class="c-footer__navLink">
										<a href="developers/">Developers</a>
									</li>
								</ul>
							</div>
						</li>
						<li class="c-footer__column -mobileAccordion">
							<div class="c-footer__columnList">
								<span class="c-footer__titleTextHead">Solutions</span>
								<button type="button" class="c-footer__navBtn js-navBtn" aria-expanded="false" data-nav-links="#solutionsLinks">
									<span class="c-footer__titleText">Solutions</span>
									<svg aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg" width="31" height="30" viewBox="0 0 31 30" fill="none">
										<path d="M8 15H23" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
										<path d="M15.5 22.5V7.5" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
									</svg>
								</button>
								<ul id="solutionsLinks" class="c-footer__navLinks">
									<li role="presentation" class="c-footer__navLink">
										<a href="solutions/">All Solutions</a>
									</li>
									<li role="presentation" class="c-footer__navLink">
										<a href="products/upms">UPMS</a>
									</li>
									<li role="presentation" class="c-footer__navLink">
										<a href="products/BBPS-on-WhatsApp">Bharat BillPay on WhatsApp</a>
									</li>
									<li role="presentation" class="c-footer__navLink">
										<a href="products/UPI-123Pay">UPI 123Pay</a>
									</li>
									<li role="presentation" class="c-footer__navLink">
										<a href="products/clickpay">ClickPay</a>
									</li>
									<li role="presentation" class="c-footer__navLink">
										<a href="products/UPI-AutoPay">UPI AutoPay</a>
									</li>
									<li role="presentation" class="c-footer__navLink">
										<a href="products/BOAT">BOAT</a>
									</li>
									<li role="presentation" class="c-footer__navLink">
										<a href="products/CertPlay">CertPlay</a>
									</li>
									<li role="presentation" class="c-footer__navLink">
										<a href="products/NOCS">NOCS</a>
									</li>
									<li role="presentation" class="c-footer__navLink">
										<a href="#" class="c-externalLinkArrow__container">
											Bharat BillPay on Nfinite&nbsp;<img width="16" height="16" class="c-externalLinkArrow" src="assets/images/empty.webp" data-image data-common-src="assets/images/vectors/icons/icon_grayExternalArrow.svg" />
										</a>
									</li>
								</ul>
							</div>
						</li>
						<li class="c-footer__column -mobileAccordion">
							<!-- Categories -->
							<div class="c-footer__columnList">
								<span class="c-footer__titleTextHead">Categories</span>
								<button type="button" class="c-footer__navBtn js-navBtn" aria-expanded="false" data-nav-links="#categoriesLinks">
									<span class="c-footer__titleText">Categories</span>
									<svg aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg" width="31" height="30" viewBox="0 0 31 30" fill="none">
										<path d="M8 15H23" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
										<path d="M15.5 22.5V7.5" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
									</svg>
								</button>
								<ul id="categoriesLinks" class="c-footer__navLinks">
									<li role="presentation" class="c-footer__navLink">
										<a href="categories/">All Categories</a>
									</li>
								</ul>
							</div>
							<!-- Circulars -->
							<div class="c-footer__columnList">
								<span class="c-footer__titleTextHead">Circulars</span>
								<button type="button" class="c-footer__navBtn js-navBtn" aria-expanded="false" data-nav-links="#circularsLinks">
									<span class="c-footer__titleText">Circulars</span>
									<svg aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg" width="31" height="30" viewBox="0 0 31 30" fill="none">
										<path d="M8 15H23" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
										<path d="M15.5 22.5V7.5" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
									</svg>
								</button>
								<ul id="circularsLinks" class="c-footer__navLinks">
									<li role="presentation" class="c-footer__navLink">
										<a href="circulars/">All Circulars</a>
									</li>
								</ul>
							</div>
							<!-- News & Resources -->
							<div class="c-footer__columnList">
								<span class="c-footer__titleTextHead">News & Resources</span>
								<button type="button" class="c-footer__navBtn js-navBtn" aria-expanded="false" data-nav-links="#newsLinks">
									<span class="c-footer__titleText">News & Resources</span>
									<svg aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg" width="31" height="30" viewBox="0 0 31 30" fill="none">
										<path d="M8 15H23" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
										<path d="M15.5 22.5V7.5" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
									</svg>
								</button>
								<ul id="newsLinks" class="c-footer__navLinks">
									<li role="presentation" class="c-footer__navLink"><a href="media-room/">Media Room</a></li>
									<li role="presentation" class="c-footer__navLink"><a href="resources/">Resources</a></li>
									<li role="presentation" class="c-footer__navLink"><a href="brand-centre/">Brand Centre</a></li>
								</ul>
							</div>
							<!-- Statistics -->
							<div class="c-footer__columnList">
								<span class="c-footer__titleTextHead">Statistics</span>
								<button type="button" class="c-footer__navBtn js-navBtn" aria-expanded="false" data-nav-links="#statisticsLinks">
									<span class="c-footer__titleText">Statistics</span>
									<svg aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg" width="31" height="30" viewBox="0 0 31 30" fill="none">
										<path d="M8 15H23" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
										<path d="M15.5 22.5V7.5" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
									</svg>
								</button>
								<ul id="statisticsLinks" class="c-footer__navLinks">
									<li role="presentation" class="c-footer__navLink">
										<a href="statistics/">Bharat BillPay Ecosystem Statistics</a>
									</li>
								</ul>
							</div>
						</li>

						<li class="c-footer__column -mobileAccordion">
							<!-- About Bharat BillPay -->
							<div class="c-footer__columnList">
								<span class="c-footer__titleTextHead">About Bharat BillPay</span>
								<button type="button" class="c-footer__navBtn js-navBtn" aria-expanded="false" data-nav-links="#aboutLinks">
									<span class="c-footer__titleText">About Bharat BillPay</span>
									<svg aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg" width="31" height="30" viewBox="0 0 31 30" fill="none">
										<path d="M8 15H23" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
										<path d="M15.5 22.5V7.5" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
									</svg>
								</button>
								<ul id="aboutLinks" class="c-footer__navLinks">
									<li role="presentation" class="c-footer__navLink"><a href="about/">About</a></li>
									<li role="presentation" class="c-footer__navLink"><a href="csr/">Corporate Social Responsibility</a></li>
									<li role="presentation" class="c-footer__navLink"><a href="corporate-governance/">Corporate Governance</a></li>
									<li role="presentation" class="c-footer__navLink"><a href="careers/">Careers</a></li>
								</ul>
							</div>
							<!-- Regulator -->
							<div class="c-footer__columnList">
								<span class="c-footer__titleTextHead">Regulator</span>
								<button type="button" class="c-footer__navBtn js-navBtn" aria-expanded="false" data-nav-links="#regulatorLinks">
									<span class="c-footer__titleText">Regulator</span>
									<svg aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg" width="31" height="30" viewBox="0 0 31 30" fill="none">
										<path d="M8 15H23" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
										<path d="M15.5 22.5V7.5" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
									</svg>
								</button>
								<ul id="regulatorLinks" class="c-footer__navLinks">
									<li role="presentation" class="c-footer__navLink">
										<a href="https://www.rbi.org.in/" target="_blank" rel="noopener noreferrer" class="c-externalLinkArrow__container">
											RBI&nbsp;<img width="16" height="16" class="c-externalLinkArrow" src="assets/images/empty.webp" data-image data-common-src="assets/images/vectors/icons/icon_grayExternalArrow.svg" />
										</a>
									</li>
								</ul>
							</div>
						</li>
						<li class="c-footer__column -mobileAccordion">
							<div class="c-footer__columnList">
								<span class="c-footer__titleTextHead">Support</span>
								<button type="button" class="c-footer__navBtn js-navBtn" aria-expanded="false" data-nav-links="#supportLinks">
									<span class="c-footer__titleText">Support</span>
									<svg aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg" width="31" height="30" viewBox="0 0 31 30" fill="none">
										<path d="M8 15H23" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
										<path d="M15.5 22.5V7.5" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
									</svg>
								</button>
								<ul id="supportLinks" class="c-footer__navLinks">
									<li role="presentation" class="c-footer__navLink">
										<a href="support/">Contact</a>
									</li>
									<li role="presentation" class="c-footer__navLink">
										<a href="support/join-bbps/">Inquire to become a partner</a>
									</li>
									<li role="presentation" class="c-footer__navLink">
										<a href="support/raise-complaint-customer/">Raise a complaint</a>
									</li>
								</ul>
							</div>
						</li>
					</ul>
				</nav>
				<!-- subscribe and socialmedia -->
				<div class="c-footer__mdlRow">
					<div class="c-footer__mdlCols js-subscribe">
						<!-- c-subscribeForm -->
						<form class="c-subscribeForm js-subscribeForm" novalidate onsubmit="event.preventDefault()">
							<h2 class="c-subscribeForm__title">Stay updated about Bharat BillPay</h2>
							<div class="c-subscribeForm__emailInputWrapper">
								<input type="email" name="c-subscribeForm__emailInput" class="c-subscribeForm__emailInput js-subscribeForm__emailInput" aria-label="Email address" placeholder="Email address" />
								<button type="submit" aria-label="Submit Email address" class="c-subscribeForm__btn js-subscribeForm__submitBtn">
									<span class="c-subscribeForm__btnTxt">Subscribe</span>
								</button>
								<p class="c-subscribeForm__emailInputError">Please enter a valid email.</p>
								<p class="c-subscribeForm__emailInputUnexpectedError">An unexpected error occurred. Please try again.</p>
								<p class="c-subscribeForm__emailInputSuccess">Subscription Successful.</p>
								<p class="c-subscribeForm__emailInputSame">Looks like you have already subscribed!</p>
							</div>
						</form>
					</div>
					<div class="c-footer__mdlCols">
						<ul class="c-footer__socialMediaLinks">
							<li>
								<a href="https://www.instagram.com/bharatbillpay_/?hl=en" target="_blank" rel="noopener noreferrer" aria-label="Follow BBPS on Instagram">
									<img alt="" width="30" height="30" src="assets/images/empty.webp" data-image data-common-src="assets/images/vectors/icons/footer/icon_instagram.svg" />
								</a>
							</li>
							<li>
								<a href="https://twitter.com/BharatBillPay" target="_blank" rel="noopener noreferrer" aria-label="Follow BBPS on Twitter">
									<img alt="" width="30" height="30" src="assets/images/empty.webp" data-image data-common-src="assets/images/vectors/icons/footer/icon_twitter.svg" />
								</a>
							</li>
							<li>
								<a href="https://www.youtube.com/@bharatbillpaymentsystem456" rel="noopener noreferrer" target="_blank" aria-label="Follow BBPS on Youtube">
									<img alt="" width="30" height="30" src="assets/images/empty.webp" data-image data-common-src="assets/images/vectors/icons/footer/icon_youtube.svg" />
								</a>
							</li>
							<li>
								<a href="https://www.facebook.com/BharatBillPay" target="_blank" rel="noopener noreferrer" aria-label="Follow BBPS on Facebook">
									<img alt="" width="30" height="30" src="assets/images/empty.webp" data-image data-common-src="assets/images/vectors/icons/footer/icon_facebook.svg" />
								</a>
							</li>
							<li>
								<a href="https://www.linkedin.com/company/bharat-billpay" rel="noopener noreferrer" target="_blank" aria-label="Follow BBPS on LinkedIn">
									<img alt="" width="30" height="30" src="assets/images/empty.webp" data-image data-common-src="assets/images/vectors/icons/footer/icon_linkedin.svg" />
								</a>
							</li>
						</ul>
					</div>
				</div>

				<div class="c-footer__legal">
					<div class="c-footer__legalCol">
						<ul class="c-footer__legalColList">
							<li class="c-footer__legalColListItem">
								<a href="legal/copyrights">Copyrights</a>
							</li>
							<li class="c-footer__legalColListItem">
								<a href="legal/policies">Policies</a>
							</li>
							<li class="c-footer__legalColListItem">
								<a href="legal/disclaimer">Disclaimer</a>
							</li>
							<li class="c-footer__legalColListItem">
								<a href="sitemap/">Sitemap</a>
							</li>
						</ul>
					</div>
					<div class="c-footer__legalCol">
						<p class="c-footer__copyright">
							&copy;<span class="c-footer__year js-currentYear">2021</span> NPCI Bharat BillPay Limited. All rights reserved. &nbsp; CIN: U67190MH2020PLC351595
						</p>
						<!-- <p class="c-footer__cin js-footerCIN"></p> -->
					</div>
				</div>
			</div>
		</footer>

	</main>



	<script src="js/main.min.js"></script>
	<script src="dependencies/AesUtil.min.js"></script>
	<script src="dependencies/crypto-js.js"></script>
	<?php if ($coolDownResume ?? '') : ?>
		<script>
			window.coolDoneResume = parseInt('<?php echo $coolDownResume; ?>') * 1000;
		</script>
	<?php endif; ?>

	<script src="js/agent-locator-search.min.js"></script>
	<!-- Google Tag Manager (noscript) -->
	<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-55ZRVWSR" height="0" width="0" style="display: none; visibility: hidden"></iframe></noscript>
	<!-- End Google Tag Manager (noscript) -->
</body>

</html>