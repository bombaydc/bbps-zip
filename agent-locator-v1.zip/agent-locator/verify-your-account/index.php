<?php
include_once('../../customer-insights/api/config.php');
if ($_SESSION['isAgentVerify'] ?? '') {
	header('Location: ' . BASE_URL . '/agent-locator/agent-locator-search');
	exit;
}

?>
<script>
	if (sessionStorage.getItem("agent_mobile_no")) {
		sessionStorage.removeItem("agent_mobile_no");
	}
</script>
<!DOCTYPE html>
<html lang="en" data-page="agent-locator">

<head>
	<base href="../../" />
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<title>Verify Your Account | Bharat BillPay</title>
	<meta name="description" content="Sign up for a Bharat BillPay account and gain access to your transaction history. " />
	<meta name="google-site-verification" content="biehzyFvzLsFbRq7xI-UoIFRGjBcZmjJgD1iAxUflow" />
	<meta property="og:type" content="website" />
	<meta property="og:url" content="https://www.bharatbillpay.com/" />
	<meta property="og:title" content="Create Your Account | Bharat BillPay" />
	<meta property="og:description" content="Sign up for a Bharat BillPay account and gain access to your transaction history. " />
	<meta property="og:image" content="https://bdcdev.in/work/bharatbillpay.com/latest/assets/images/pages/social-share-bbps.jpg" />
	<meta name="twitter:card" content="summary_large_image" />
	<meta name="twitter:site" content="@BharatBillPay" />
	<meta name="twitter:creator" content="@BharatBillPay" />
	<meta name="twitter:title" content="Create Your Account | Bharat BillPay" />
	<meta name="twitter:description" content="Sign up for a Bharat BillPay account and gain access to your transaction history. " />
	<meta name="twitter:image" content="https://bdcdev.in/work/bharatbillpay.com/latest/assets/images/pages/social-share-bbps.jpg" />
	<link rel="shortcut icon" href="assets/favicon/favicon.png" type="image/x-icon" />
	<link rel="stylesheet" type="text/css" href="css/main.min.css" />
	<link rel="stylesheet" type="text/css" href="css/pages/agent-locator/index.min.css" />
	<link rel="preconnect" href="https://fonts.googleapis.com" />
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500&display=swap" rel="stylesheet" />
	<!-- Google tag (gtag.js) -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=UA-113582445-1"></script>
	<script>
		window.dataLayer = window.dataLayer || [];

		function gtag() {
			dataLayer.push(arguments);
		}
		gtag("js", new Date());

		gtag("config", "UA-113582445-1");
	</script>
	<!-- Google tag (gtag.js) -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=G-NSHLRBR254"></script>
	<script>
		window.dataLayer = window.dataLayer || [];

		function gtag() {
			dataLayer.push(arguments);
		}
		gtag("js", new Date());

		gtag("config", "G-NSHLRBR254");
	</script>
	<!-- Clarity -->
	<script type="text/javascript">
		(function(c, l, a, r, i, t, y) {
			c[a] =
				c[a] ||
				function() {
					(c[a].q = c[a].q || []).push(arguments);
				};
			t = l.createElement(r);
			t.async = 1;
			t.src = "https://www.clarity.ms/tag/" + i;
			y = l.getElementsByTagName(r)[0];
			y.parentNode.insertBefore(t, y);
		})(window, document, "clarity", "script", "hquvwne1n0");
	</script>
	<!-- Google Tag Manager -->
	<script>
		(function(w, d, s, l, i) {
			w[l] = w[l] || [];
			w[l].push({
				"gtm.start": new Date().getTime(),
				event: "gtm.js",
			});
			var f = d.getElementsByTagName(s)[0],
				j = d.createElement(s),
				dl = l != "dataLayer" ? "&l=" + l : "";
			j.async = true;
			j.src = "https://www.googletagmanager.com/gtm.js?id=" + i + dl;
			f.parentNode.insertBefore(j, f);
		})(window, document, "script", "dataLayer", "GTM-55ZRVWSR");
	</script>
	<!-- End Google Tag Manager -->
</head>

<body>
	<!-- header -->
	<header class="c-header js-header" observer-animation="cssClass" observer-animation-classes="animateIn">
		<nav aria-label="BBPS Header Navigation" class="c-header__nav">
			<div class="c-header__lhs">
				<a href="" aria-label="Home"><img class="c-header__logo" alt="" width="100" height="33" src="assets/images/vectors/icon_logo.svg" /></a>
				<a href="" aria-label="Home">
					<img alt="" class="c-header__harPaymentLogo" src="assets/images/empty.webp" data-image data-desktop-src="assets/images/vectors/icon_d_harPaymentDigital.svg" data-mobile-src="assets/images/vectors/icon_d_harPaymentDigital.svg" />
				</a>
			</div>
			<div class="c-header__rhs">
				<button type="button" class="c-header__menuBtn" aria-label="toggle menu">
					<svg aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
						<path d="M2 5V7H22V5H2ZM2 11V13H22V11H2ZM2 17V19H22V17H2Z" fill="black" />
					</svg>
				</button>
			</div>
		</nav>
	</header>
	<div class="c-hamburgerMenu js-hamburgerMenu">
		<div class="c-hamburgerMenu_container">
			<div class="c-hamburgerMenu_Mob isBelow1024">
				<div class="c-hamburgerMenu_lhs__logo">
					<a href="" aria-label="Home"><img alt="" class="c-header__logo" width="100" height="33" src="assets/images/vectors/icon_logo.svg" /></a>
					<a href="" aria-label="Home">
						<img alt="" class="c-header__harPaymentLogo" src="assets/images/empty.webp" data-image data-desktop-src="assets/images/vectors/icon_d_harPaymentDigital.svg" data-mobile-src="assets/images/vectors/icon_d_harPaymentDigital.svg" />
					</a>
				</div>
				<button type="button" class="js-closeMenu mobMenu">
					<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
						<path d="M9.85259e-05 2.21585L1.36377 0.858643L15.0005 14.4308L13.6368 15.788L9.85259e-05 2.21585Z" fill="#1e1e1c" />
						<path d="M15.0014 2.21585L13.6377 0.858643L0.000985428 14.4308L1.36466 15.788L15.0014 2.21585Z" fill="#1e1e1c" />
					</svg>
				</button>
			</div>
			<div class="c-hamburgerMenu_lhs">
				<div class="c-hamburgerMenu_lhs__logo isAbove1023">
					<a href="" aria-label="Home" class="isAbove1023"><img alt="" class="c-header__logo" width="100" height="33" src="assets/images/vectors/icon_logo.svg" /></a>
					<a href="" aria-label="Home" class="isAbove1023">
						<img alt="" class="c-header__harPaymentLogo" src="assets/images/empty.webp" data-image data-desktop-src="assets/images/vectors/icon_d_harPaymentDigital.svg" data-mobile-src="assets/images/vectors/icon_m_harPaymentDigital.svg" />
					</a>
				</div>
				<ul class="c-hamburgerMenu_lhs__navList">
					<li role="presentation" class="c-hamburgerMenu_lhs__navItem anim-stagger-1">
						<a class="js-header__menuLink" href="billers/" data-item="billers">Billers</a>
					</li>
					<li role="presentation" class="c-hamburgerMenu_lhs__navItem anim-stagger-2">
						<a class="js-header__menuLink" href="operating-units/" data-item="operating units">Operating Units</a>
					</li>
					<li role="presentation" class="c-hamburgerMenu_lhs__navItem anim-stagger-3">
						<a class="js-header__menuLink" href="customers/" data-item="customers">Customers</a>
					</li>
					<li role="presentation" class="c-hamburgerMenu_lhs__navItem anim-stagger-4">
						<a class="js-header__menuLink" href="developers/" data-item="developers">Developers</a>
					</li>
				</ul>
			</div>
			<div class="c-hamburgerMenu_rhs">
				<button type="button" class="c-hamburgerMenu_rhs__closeIcon js-closeMenu isAbove1023">
					<svg xmlns="http://www.w3.org/2000/svg" width="21" height="20" viewBox="0 0 21 20" fill="none">
						<path d="M0.000135702 1.81818L1.81836 0L20.0006 18.1818L18.1824 19.9999L0.000135702 1.81818Z" fill="white" />
						<path d="M20.0018 1.81818L18.1836 0L0.00135938 18.1818L1.81958 19.9999L20.0018 1.81818Z" fill="white" />
					</svg>
				</button>
				<div class="c-hamburgerMenu_rhs__bg">
					<svg width="798" height="666" viewBox="0 0 798 666" fill="none" xmlns="http://www.w3.org/2000/svg">
						<g clip-path="url(#clip0_1_20)">
							<path opacity="0.2" d="M18 0C17.9998 77 111.015 166.5 180.508 213C250 259.5 342.008 316.5 364.004 330C386 343.5 457.008 388.5 375.508 384C251.816 377.17 26.0075 339 95.5075 486C165.008 633 408.508 652.5 498.508 647.5C588.508 642.5 699.008 605.5 816.508 514.5" stroke="url(#paint0_linear_1_20)" stroke-width="35" />
						</g>
						<defs>
							<linearGradient id="paint0_linear_1_20" x1="18" y1="44.5" x2="796.5" y2="519" gradientUnits="userSpaceOnUse">
								<stop stop-color="white" />
								<stop offset="1" stop-color="white" stop-opacity="0.06" />
							</linearGradient>
							<clipPath id="clip0_1_20">
								<rect width="798" height="666" fill="white" />
							</clipPath>
						</defs>
					</svg>
				</div>
				<div class="c-hamburgerMenu_rhs__list">
					<ul class="c-hamburgerMenu_rhs__navList">
						<li role="presentation" class="c-hamburgerMenu_rhs__navItem anim-stagger-1">
							<a class="js-header__menuLink" href="solutions/">Solutions</a>
						</li>
						<li role="presentation" class="c-hamburgerMenu_rhs__navItem anim-stagger-2">
							<a class="js-header__menuLink" href="categories/">Categories</a>
						</li>
						<li role="presentation" class="c-hamburgerMenu_rhs__navItem anim-stagger-3">
							<a class="js-header__menuLink" href="circulars/">Circulars</a>
						</li>
						<li role="presentation" class="c-hamburgerMenu_rhs__navItem anim-stagger-4">
							<a class="js-header__menuLink" href="statistics/">Statistics</a>
						</li>
						<li role="presentation" class="c-hamburgerMenu_rhs__navItem anim-stagger-5">
							<a class="js-header__menuLink" href="about/">About</a>
						</li>
						<li role="presentation" class="c-hamburgerMenu_rhs__navItem anim-stagger-6">
							<a class="js-header__menuLink" href="support/">Support</a>
						</li>
						<li role="presentation" class="c-hamburgerMenu_rhs__navItem anim-stagger-7">
							<a class="js-header__menuLink" href="corporate-governance/">Corporate Governance</a>
						</li>
					</ul>
					<ul class="c-hamburgerMenu_rhs__navList">
						<li role="presentation" class="c-hamburgerMenu_rhs__navItem anim-stagger-8">
							<a class="js-header__menuLink" href="legal/copyrights/">Copyrights</a>
						</li>
						<li role="presentation" class="c-hamburgerMenu_rhs__navItem anim-stagger-9">
							<a class="js-header__menuLink" href="legal/privacy-security-policy/">Policies</a>
						</li>
						<li role="presentation" class="c-hamburgerMenu_rhs__navItem anim-stagger-10">
							<a class="js-header__menuLink" href="legal/disclaimer/">Disclaimer</a>
						</li>
						<li role="presentation" class="c-hamburgerMenu_rhs__navItem anim-stagger-11">
							<a class="js-header__menuLink" href="sitemap/">Sitemap</a>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	<div class="c-scrollProgress js-scrollProgress"></div>
	<main>
		<!-- c-breadcrumbs -->
		<div class="c-breadcrumbs" observer-animation="cssClass" observer-animation-classes="animateIn">
			<a href="">Home</a>
			<span>/</span>
			<a href="agent-locator/">Agent Locator</a>
		</div>

		<!-- banner -->
		<section class="section banner" observer-animation="cssClass" observer-animation-classes="animateIn">
			<h1 class="banner__heading40 anim-stagger-1">Enter mobile number to begin <br class="isAbove1023"> your search</h1>
		</section>
		<!-- transactionFormContainer -->
		<section class="section transactionFormContainer -createYourAccountForm js-createYourAccount" observer-animation="cssClass" observer-animation-classes="animateIn">
			<!-- form -->
			<form class="transactionFormContainer__form c-form anim-stagger-3" novalidate>
				<!-- tel -->
				<div class="c-form__inputWrapper" data-server-validation-id="mobile_no">
					<div class="c-form__mobileNumberWrapper">
						<span class="c-form__inputPrefix">+91</span>
						<input class="c-form__input -mobileNumber" type="tel" name="tel" id="tel" placeholder="" />
						<p class="c-form__serverError js-formInputServerError"></p>
						<p class="c-form__error -isEmpty">Please enter a mobile number.</p>
						<p class="c-form__error -isInvalid">Please enter a valid 10-digit mobile number.</p>
						<!-- use isExist or isInfo in thee input element class to show this info -->
						<!-- <p class="c-form__info -isSame">Your number +91 9820098300 is already registered with us. Try <a href="agent-locator/log-in" class="transactionLink">logging in</a> instead?</p> -->
					</div>
				</div>
				<!-- submit -->
				<div class="transactionFormContainer__submitBtnWrapper">
					<button type="submit" disabled class="transactionFormContainer__submitBtn js-createYourAccountBtn c-btn -fill">
						<span class="c-btn__text">Verify</span>
					</button>
				</div>
			</form>
			<!-- submitted -->
			<div class="transactionFormContainer__submitted">
				<svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 30 30" fill="none">
					<path d="M15 27.5C21.875 27.5 27.5 21.875 27.5 15C27.5 8.125 21.875 2.5 15 2.5C8.125 2.5 2.5 8.125 2.5 15C2.5 21.875 8.125 27.5 15 27.5Z" stroke="#7AC51C" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
					<path d="M9.6875 15L13.225 18.5375L20.3125 11.4625" stroke="#7AC51C" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
				</svg>
				<p>Thank you for <br class="isBelow1024" />submitting the form. <br />Our team will get in <br class="isBelow1024" />touch with you soon.</p>
			</div>
		</section>
		<!-- login bottom -->
		<section class="section transactionLogin">
			<p class="transactionLogin__para">Or, click here to
				<a href="#" class="c-btn transactionLogin__cta">
					<span class="c-btn__text">pay bills online</span>
				</a>
			</p>
		</section>
	</main>
	<script src="dependencies/AesUtil.min.js"></script>
	<script src="dependencies/crypto-js.js"></script>
	<script src="js/main.min.js"></script>
	<script src="js/agent-locator.min.js"></script>
	<style>
		.c-btn[disabled]:hover {
			pointer-events: none;
			background-color: #d2d2d2;
		}
	</style>
	<script src="dependencies/jquery.min.js"></script>
	<script>
		var jq = $.noConflict();
		sessionStorage.setItem("page", "agent-located-login");
	</script>
	<!-- <script src="dependencies/transaction.js"></script> -->
	<script src="dependencies/agent-login.js"></script>
	<!-- Google Tag Manager (noscript) -->
	<noscript><iframe title="User Behaviour Tracking Via GTM" src="https://www.googletagmanager.com/ns.html?id=GTM-55ZRVWSR" height="0" width="0" style="display: none; visibility: hidden"></iframe></noscript>
	<!-- End Google Tag Manager (noscript) -->
</body>

</html>